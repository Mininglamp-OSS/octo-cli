package service

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/url"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/spf13/cobra"

	"github.com/Mininglamp-OSS/octo-cli/internal/client"
	"github.com/Mininglamp-OSS/octo-cli/internal/cmdutil"
	"github.com/Mininglamp-OSS/octo-cli/internal/output"
	"github.com/Mininglamp-OSS/octo-cli/internal/registry"
)

// runOperation is the RunE body for every auto-registered operation.
// Builds the outbound request from flags/args, dispatches (with pagination
// if requested), and emits the envelope.
func runOperation(cobraCmd *cobra.Command, f *cmdutil.Factory, rt *operationRuntime, args []string) error {
	ctx := cobraCmd.Context()
	d := rt.detail

	positionalQueryStart := len(args) - len(rt.queryPositionals)
	pathArgs := args[:positionalQueryStart]
	positionalQueryValues := args[positionalQueryStart:]

	// Path substitution. Cobra's Args function already checked the argument count.
	urlPath := MarketplacePath(d.Service, d.Path)
	// Identity routing: reject an incompatible credential kind and pick the
	// server mount for the one in use, before any path parameter is filled in.
	urlPath, err := applyIdentityRouting(f, d, urlPath)
	if err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	// Path values come from the positional args, except for slots a
	// spec-declared path flag filled in (the escape hatch for ids starting
	// with "-").
	pathValues, verr := resolvePathValues(cobraCmd, rt, pathArgs)
	if verr != nil {
		_ = f.EmitError(verr) //nolint:errcheck // best-effort emit before returning err
		return verr
	}
	// Path values carrying a backend uint64 id are range-checked here so an
	// id mangled by an Agent's JSON parser fails locally instead of hitting a
	// backend 400 (or worse, addressing a different row).
	if verr := validatePathArgs(rt, pathValues); verr != nil {
		_ = f.EmitError(verr) //nolint:errcheck // best-effort emit before returning err
		return verr
	}
	for i, pname := range rt.pathParams {
		placeholder := "{" + pname + "}"
		urlPath = strings.ReplaceAll(urlPath, placeholder, url.PathEscape(pathValues[i]))
	}

	// Query and header parameters. Explicitly set flags and positional query values
	// are emitted, so a default never overrides a backend default and an omitted
	// optional header stays absent.
	q, headers, verr := buildQueryAndHeaders(cobraCmd, rt, positionalQueryValues)
	if verr != nil {
		return emitAndReturn(f, verr)
	}
	// A Workspace path flag and its binding header share one selector. Resolve
	// both from the same value so Fleet can authorize before route dispatch.
	headers = bindWorkspacePathHeader(rt, pathValues, headers)
	if err := applyTaskAssigneeQuery(cobraCmd, f, rt, q, headers); err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}

	// Body: start from --data (if any), then merge explicit flags on top.
	// Multipart ops take a separate path — they build a form body, not JSON.
	req := client.Request{
		Service:        d.Service,
		Credential:     d.Credential,
		Method:         d.Method,
		Path:           urlPath,
		Query:          q,
		Headers:        headers,
		BinaryResponse: d.BinaryResponse,
		// Suppress X-Space-Id only when the spec explicitly declares
		// x-octo-space-header:false. An omitted flag keeps the default
		// behaviour of sending the header when the credential has a space.
		SuppressSpaceHeader:            d.SpaceHeaderSet && !d.SpaceHeader,
		DisableRetry:                   d.RetryMode == "never",
		UnknownOutcomeOnNetworkFailure: d.RetryMode == "never",
		ResponseSecretFields:           d.ResponseSecretFields,
		SensitiveJSONFields:            writeOnlyBodyFields(d.RequestBody),
		ResponseUnwrap:                 d.ResponseUnwrap,
		UnwrapRequiredFields:           d.UnwrapRequiredFields,
	}
	// Path, query, and header secrets do not depend on the merged body.
	req.SecretValues = collectParameterSecrets(cobraCmd, rt, pathValues, positionalQueryValues)
	// Binary-response ops may carry an --output/-o destination; when set, the
	// client writes the 2xx body to that path instead of only describing it.
	if rt.outputPath != nil {
		req.OutputPath = *rt.outputPath
	}
	if d.BinaryBody {
		req.InlineBinaryLimit = f.InlineBinaryLimit
	}
	if err := attachRequestBody(f, cobraCmd, rt, &req); err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	// Forwarding an idempotency key is not proof that the backend deduplicates
	// a resend, so only a verified contract keeps the automatic retries.
	req.ReplaySafe = replayDeduplicated(rt, &req)

	// Pagination loop (--page-all). Only for operations declaring pagination.
	if rt.pageAll != nil && *rt.pageAll && (f.Globals == nil || !f.Globals.DryRun) {
		return runPaginated(ctx, f, rt, &req)
	}

	return emitOnce(ctx, f, rt, &req)
}

// buildQueryAndHeaders assembles query parameters from flags and any opt-in
// positional query values, alongside spec-declared header flags.
//
// One step rather than two because a parameter the spec marks required must
// not be forwarded empty, wherever it sits. Keeping them together also keeps
// runOperation — which is a sequence of pre-flight checks — from growing a
// branch per position.
func buildQueryAndHeaders(cobraCmd *cobra.Command, rt *operationRuntime, positionalQueryValues []string) (url.Values, map[string]string, *output.ExitError) {
	q, err := buildQuery(cobraCmd, rt)
	if err != nil {
		return nil, nil, err
	}
	if err := addPositionalQueryValues(q, rt, positionalQueryValues); err != nil {
		return nil, nil, err
	}
	if err := normalizeWorkspaceMemberPagination(rt, q); err != nil {
		return nil, nil, err
	}
	headers, err := buildHeaders(cobraCmd, rt)
	if err != nil {
		return nil, nil, err
	}
	if err := validateSheetReadSelection(rt, q); err != nil {
		return nil, nil, err
	}
	if err := applyLoopProjectQuery(cobraCmd, rt, q); err != nil {
		return nil, nil, err
	}
	return q, headers, nil
}

// Fleet's Project member route accepts page/page_size. Keep the older CLI
// limit/offset flags only when their offset names an exact page boundary.
func normalizeWorkspaceMemberPagination(rt *operationRuntime, q url.Values) *output.ExitError {
	if rt.detail.ID != "workspace.member.list" {
		return nil
	}
	pageSize, err := workspaceMemberPageSize(q)
	if err != nil {
		return err
	}
	if !q.Has("offset") {
		return nil
	}
	if q.Has("page") {
		return output.ErrValidation("--offset and --page cannot be combined", "use one page selector")
	}
	offset, parseErr := strconv.Atoi(q.Get("offset"))
	if parseErr != nil || offset < 0 || offset%pageSize != 0 {
		return output.ErrValidation("--offset must be a nonnegative multiple of the page size", "use --page for arbitrary Project pages")
	}
	// Pin the page size used for the offset calculation on the wire too.
	if !q.Has("page_size") {
		q.Set("page_size", strconv.Itoa(pageSize))
	}
	q.Set("page", strconv.Itoa(offset/pageSize+1))
	q.Del("offset")
	return nil
}

func workspaceMemberPageSize(q url.Values) (int, *output.ExitError) {
	if q.Has("limit") && q.Has("page_size") {
		return 0, output.ErrValidation("--limit and --page-size cannot be combined", "use one page-size selector")
	}
	pageSize := 50
	if raw := q.Get("limit"); raw != "" {
		value, err := strconv.Atoi(raw)
		if err != nil || value < 1 || value > 200 {
			return 0, output.ErrValidation("--limit must be between 1 and 200", "choose a valid Project member page size")
		}
		pageSize = value
		q.Set("page_size", raw)
		q.Del("limit")
	} else if raw := q.Get("page_size"); raw != "" {
		value, err := strconv.Atoi(raw)
		if err != nil || value < 1 || value > 200 {
			return 0, output.ErrValidation("--page-size must be between 1 and 200", "choose a valid Project member page size")
		}
		pageSize = value
	}
	return pageSize, nil
}

// emitAndReturn emits a validation failure and returns it, which is the shape every
// pre-flight check in runOperation shares. Factored out so adding a check does not add
// another three-line block to a function already at the complexity limit.
func emitAndReturn(f *cmdutil.Factory, err *output.ExitError) error {
	_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
	return err
}

// attachRequestBody selects the multipart, raw-body or JSON encoder.
func attachRequestBody(f *cmdutil.Factory, cmd *cobra.Command, rt *operationRuntime, req *client.Request) error {
	if rt.detail.RawBody {
		raw, err := buildRawBody(rt, f.MultipartFile)
		if err != nil {
			return err
		}
		req.RawBody, req.ContentType = raw, rt.detail.RawBodyContentType
		return nil
	}
	if !rt.detail.Multipart {
		return attachJSONBody(f, cmd, rt, req)
	}
	raw, contentType, err := buildMultipartBody(cmd, rt, f.MultipartFile)
	if err != nil {
		return err
	}
	req.RawBody, req.ContentType = raw, contentType
	return nil
}

// attachJSONBody resolves and validates JSON, then collects declared secrets.
func attachJSONBody(f *cmdutil.Factory, cobraCmd *cobra.Command, rt *operationRuntime, req *client.Request) error {
	body, err := resolveBody(f, cobraCmd, rt)
	if err != nil {
		return err
	}
	// Reject index-less / malformed-index whiteboard elements locally, before
	// sending, for operations that declare it in the spec (docs.scene.edit).
	if rt.detail.ValidateElementsIndex {
		if verr := validateElementsIndex(body); verr != nil {
			return verr
		}
	}
	if rt.detail.ValidateMarketplaceRelations {
		if verr := validateMarketplaceRelations(body, rt.detail.ID == "plugin.review_request.create"); verr != nil {
			return verr
		}
	}
	req.Body = body
	if body == nil || rt.detail.RequestBody == nil {
		return nil
	}
	bodySecrets, err := CollectRequestSecrets(rt.detail, body)
	if err != nil {
		return output.ErrValidation(fmt.Sprintf("--data: %v", err),
			"quote the value — a declared secret is masked by string rules, and an unquoted one would print in full")
	}
	req.SecretValues = append(req.SecretValues, bodySecrets...)
	return nil
}

// resolvePathValues fills one value per path parameter, in path order. A slot
// whose spec parameter declares x-octo-flag takes the flag's value when the
// caller set it; every other slot consumes the next positional argument.
//
// Operations with no flagged path param keep cobra.ExactArgs, so this is a
// straight copy of args for them.
func resolvePathValues(cobraCmd *cobra.Command, rt *operationRuntime, args []string) ([]string, *output.ExitError) {
	if len(rt.pathFlags) == 0 {
		return args, nil
	}
	byParam := make(map[string]*pathFlag, len(rt.pathFlags))
	for _, pf := range rt.pathFlags {
		byParam[pf.paramName] = pf
	}

	values := make([]string, 0, len(rt.pathParams))
	next := 0
	for _, name := range rt.pathParams {
		if pf := byParam[name]; pf != nil && cobraCmd.Flags().Changed(pf.flagName) {
			values = append(values, *pf.strVal)
			continue
		}
		if next < len(args) {
			values = append(values, args[next])
			next++
			continue
		}
		return nil, missingPathValueError(cobraCmd, name, byParam[name])
	}
	if next < len(args) {
		// The extra argument is not echoed: for the operations that have a path
		// flag it is by construction the id, and this check runs before
		// collectSecrets. Naming which mistake was made is the actionable part.
		return nil, output.ErrValidation(
			"a path value was supplied both positionally and by flag",
			"a path value supplied by flag must not also be given positionally; drop one of the two")
	}
	return values, nil
}

// missingPathValueError names both ways to supply the value, so a caller who
// hit the leading-dash trap is told the flag form exists.
func missingPathValueError(cobraCmd *cobra.Command, paramName string, pf *pathFlag) *output.ExitError {
	arg := "<" + strings.ReplaceAll(paramName, "_", "-") + ">"
	if pf == nil {
		return output.ErrValidation(fmt.Sprintf("missing required argument %s", arg),
			fmt.Sprintf("see `%s --help`", cobraCmd.CommandPath()))
	}
	return output.ErrValidation(
		fmt.Sprintf("missing required argument %s (or --%s)", arg, pf.flagName),
		fmt.Sprintf("%s --%s <value>; an id starting with \"-\" needs the flag form "+
			"or a \"--\" separator: %s -- -Ab3cD…",
			cobraCmd.CommandPath(), pf.flagName, cobraCmd.CommandPath()))
}

// validatePathArgs checks every resolved path value before it is substituted
// into the URL: no value may be empty or a dot segment, and a value whose spec
// parameter is a backend uint64 id (integer / format uint64) is range-checked.
// Non-id path params are otherwise left alone, so the format check is a no-op for
// every operation that does not declare it.
//
// Both structural checks run for flag-supplied and positional values alike. The
// empty check used to live in resolvePathValues and covered only the flag form,
// which is the less common spelling of the mistake it was written for.
func validatePathArgs(rt *operationRuntime, values []string) *output.ExitError {
	for i, name := range rt.pathParams {
		if i >= len(values) {
			return nil
		}
		arg := "<" + strings.ReplaceAll(name, "_", "-") + ">"
		if err := rejectEmptyPathValue(arg, values[i]); err != nil {
			return err
		}
		if err := rejectDotSegment(arg, values[i]); err != nil {
			return err
		}
		p := findParam(rt.detail, name, "path")
		if p == nil || p.Format != uint64Format {
			continue
		}
		if _, err := output.ParseUint64Decimal(arg, values[i]); err != nil {
			return err
		}
	}
	return nil
}

// rejectEmptyPathValue refuses an empty path value, which would address the
// collection URL instead of a resource: `drive share revoke "$SHARE_ID"` with an
// unset variable would send DELETE to {mount}/shares/ rather than fail, and the
// same holds for the --share-id spelling. cobra used to catch the positional case
// as a missing argument; MaximumNArgs no longer does, and no domain has ever had
// an id that is the empty string.
func rejectEmptyPathValue(label, value string) *output.ExitError {
	if value != "" {
		return nil
	}
	return output.ErrValidation(
		fmt.Sprintf("%s is empty", label),
		"pass the id value; an empty path value would address the collection, not a resource")
}

// rejectDotSegment refuses a path value that is exactly "." or "..".
//
// url.PathEscape does not escape a dot, so both reach the URL as real dot
// segments. A single segment cannot climb more than one level (a "/" would be
// escaped), which bounds this — but the engine emits DELETE for high-risk-write
// operations, and any gateway that normalises dot segments turns
// `DELETE /shares/..` into `DELETE /shares`. Whether such a route exists is a
// backend question the CLI should not be asking, so the value is refused here.
// No backend id shape is "." or "..", so nothing legitimate is lost.
func rejectDotSegment(label, value string) *output.ExitError {
	if value != "." && value != ".." {
		return nil
	}
	return output.ErrValidation(
		fmt.Sprintf("%s must be an id, not the path segment %q", label, value),
		"pass the id value; a dot segment would retarget the request at a different resource")
}

// collectParameterSecrets gathers secret path, query, and header parameter values.
func collectParameterSecrets(
	cobraCmd *cobra.Command,
	rt *operationRuntime,
	pathValues, positionalQueryValues []string,
) []string {
	var secrets []string
	add := func(v string) {
		if v != "" {
			secrets = append(secrets, v)
		}
	}
	for i, name := range rt.pathParams {
		if i >= len(pathValues) {
			break
		}
		if p := findParam(rt.detail, name, "path"); p != nil && p.Secret {
			add(pathValues[i])
		}
	}
	for i, qp := range rt.queryPositionals {
		if qp.Secret {
			add(positionalQueryValues[i])
		}
	}
	for flagName, qf := range rt.queryFlags {
		if qf.secret {
			add(changedFlagValue(cobraCmd, flagName, qf.strVal))
		}
	}
	for flagName, hf := range rt.headerFlags {
		if hf.secret {
			add(changedFlagValue(cobraCmd, flagName, hf.strVal))
		}
	}
	return secrets
}

// changedFlagValue returns a string flag's value only if the user set it and the
// flag is string-backed, else "". Secrets are always string-valued, so a
// non-string binding is simply not a secret to mask.
func changedFlagValue(cobraCmd *cobra.Command, flagName string, val *string) string {
	if val == nil || !cobraCmd.Flags().Changed(flagName) {
		return ""
	}
	return *val
}

// findParam locates a spec parameter by wire name and location.
// rejectEmptyRequiredValue refuses an empty value for a parameter the spec marks required,
// in any position.
//
// It is rejectEmptyPathValue's sibling, and exists because that guard was applied to exactly
// one of the three places a parameter can sit while the unset-shell-variable failure it was
// written for is identical in the other two. cobra's MarkFlagRequired only checks whether the
// flag was *given*, so `--flag ""` satisfies the required gate and the empty value goes on the
// wire: `--space-id ""` produced `?space_id=`, emptying a required scope, and `--base-version ""`
// produced `If-Match: `, which is not a valid entity-tag list — the idiomatic server-side read
// (`if h := r.Header.Get("If-Match"); h != ""`) then skips the compare-and-swap entirely, so the
// concurrency gate the spec marks required is silently defeated and a collaborative edit loses
// an update.
//
// Gated on the spec's own `required`, so an optional parameter may still be sent empty: a
// backend may read that as "clear this filter", and narrowing it would be a contract change
// beyond the defect.
func rejectEmptyRequiredValue(label, value string, required bool) *output.ExitError {
	if !required || value != "" {
		return nil
	}
	return output.ErrValidation(
		fmt.Sprintf("%s is empty, but this operation requires a value", label),
		"pass a value: the required-flag check only sees whether the flag was given, so an "+
			"empty string satisfies it while the request carries no value at all")
}

// paramRequired reports whether the spec marks the named parameter required in that position.
func paramRequired(d *registry.OperationDetail, apiName, in string) bool {
	p := findParam(d, apiName, in)
	return p != nil && p.Required
}

func findParam(d *registry.OperationDetail, name, in string) *registry.ParamInfo {
	if d == nil {
		return nil
	}
	for i := range d.Parameters {
		if d.Parameters[i].Name == name && d.Parameters[i].In == in {
			return &d.Parameters[i]
		}
	}
	return nil
}

// MarketplacePath lets local development bypass the production /market
// gateway mount. When OCTO_MARKETPLACE_API_PREFIX is present, its value
// replaces the leading /market segment; setting it to an empty string maps
// /market/api/v1/... to the standalone service's /api/v1/... routes.
func MarketplacePath(service, path string) string {
	if service != "marketplace" || !strings.HasPrefix(path, "/market/") {
		return path
	}
	prefix, ok := os.LookupEnv("OCTO_MARKETPLACE_API_PREFIX")
	if !ok {
		return path
	}
	prefix = strings.TrimSpace(prefix)
	if prefix != "" && !strings.HasPrefix(prefix, "/") {
		prefix = "/" + prefix
	}
	return strings.TrimSuffix(prefix, "/") + strings.TrimPrefix(path, "/market")
}

// buildQuery assembles the URL query from flags the user explicitly set, so
// a default never overrides a backend default. Conditional query requirements,
// enum checks, and wire formatting are applied before the request leaves.
func buildQuery(cobraCmd *cobra.Command, rt *operationRuntime) (url.Values, *output.ExitError) {
	if err := validateConditionalQueryRequirements(cobraCmd, rt); err != nil {
		return nil, err
	}
	q := url.Values{}
	for flagName, qf := range rt.queryFlags {
		if !loopFlagChanged(cobraCmd, flagName) {
			continue
		}
		if err := addQueryFlagValue(q, rt, flagName, qf); err != nil {
			return nil, err
		}
	}
	return q, nil
}

// addQueryFlagValue validates and serializes one explicitly set query flag.
func addQueryFlagValue(
	q url.Values,
	rt *operationRuntime,
	flagName string,
	qf *queryFlag,
) *output.ExitError {
	enum := queryEnum(rt.detail, qf.apiName)
	label := "--" + flagName
	required := paramRequired(rt.detail, qf.apiName, "query")
	switch qf.kind {
	case kindInt:
		if err := checkEnum(label, *qf.intVal, enum); err != nil {
			return err
		}
		q.Set(qf.apiName, strconv.Itoa(*qf.intVal))
	case kindFloat64:
		if err := checkEnum(label, *qf.floatVal, enum); err != nil {
			return err
		}
		q.Set(qf.apiName, strconv.FormatFloat(*qf.floatVal, 'f', -1, 64))
	case kindBool:
		if err := checkEnum(label, *qf.boolVal, enum); err != nil {
			return err
		}
		q.Set(qf.apiName, strconv.FormatBool(*qf.boolVal))
	case kindStringSlice:
		if err := addSliceQueryValues(q, qf, rt, label, required); err != nil {
			return err
		}
	case kindUint64:
		n, err := output.ParseUint64Decimal(label, *qf.strVal)
		if err != nil {
			return err
		}
		if err := checkEnum(label, n, enum); err != nil {
			return err
		}
		q.Set(qf.apiName, *qf.strVal)
	default:
		if err := rejectEmptyRequiredValue(label, *qf.strVal, required); err != nil {
			return err
		}
		if err := checkEnum(label, *qf.strVal, enum); err != nil {
			return err
		}
		q.Set(qf.apiName, *qf.strVal)
	}
	return nil
}

func addPositionalQueryValues(q url.Values, rt *operationRuntime, values []string) *output.ExitError {
	for i, p := range rt.queryPositionals {
		value := values[i]
		label := "<" + p.PositionalName + ">"
		if value == "" {
			return output.ErrValidation(
				fmt.Sprintf("%s is empty, but this operation requires a value", label),
				"pass a non-empty query value; an empty search term is not usable")
		}
		if err := checkEnum(label, value, p.Enum); err != nil {
			return err
		}
		q.Set(p.Name, value)
	}
	return nil
}

func validateConditionalQueryRequirements(cobraCmd *cobra.Command, rt *operationRuntime) *output.ExitError {
	for i := range rt.detail.Parameters {
		p := &rt.detail.Parameters[i]
		if p.In != "query" || p.RequiredUnlessQuery == nil {
			continue
		}
		flagName := paramFlagName(p)
		peer := findParam(rt.detail, p.RequiredUnlessQuery.Name, "query")
		// Registry construction validates this metadata. Keep the runtime check
		// defensive for tests that inject OperationDetail directly.
		if peer == nil || peer.Type != "string" {
			return output.ErrValidation("operation has invalid conditional query metadata", "update the embedded API specification")
		}
		peerFlag := paramFlagName(peer)
		peerValue, err := cobraCmd.Flags().GetString(peerFlag)
		if err != nil {
			return output.ErrValidation("operation has invalid conditional query metadata", "update the embedded API specification")
		}
		excepted := cobraCmd.Flags().Changed(peerFlag) && peerValue == p.RequiredUnlessQuery.Value
		if excepted {
			continue
		}
		if cobraCmd.Flags().Changed(flagName) {
			value, valueErr := cobraCmd.Flags().GetString(flagName)
			if valueErr == nil && value != "" {
				continue
			}
		}
		return output.ErrValidation(
			fmt.Sprintf("--%s is required unless --%s is %q", flagName, peerFlag, p.RequiredUnlessQuery.Value),
			fmt.Sprintf("pass a non-empty --%s, or set --%s to %s", flagName, peerFlag, p.RequiredUnlessQuery.Value))
	}
	return nil
}

// addSliceQueryValues emits every element of a repeated query flag, holding each to the
// element enum the spec declares (schema.items.enum) and to the required-non-empty rule.
//
// Kept separate so repeated values retain their element-level enum and required checks.
func addSliceQueryValues(q url.Values, qf *queryFlag, rt *operationRuntime, label string, required bool) *output.ExitError {
	itemEnum := queryItemEnum(rt.detail, qf.apiName)
	for _, v := range *qf.strSlc {
		if err := rejectEmptyRequiredValue(label, v, required); err != nil {
			return err
		}
		if err := checkEnum(label, v, itemEnum); err != nil {
			return err
		}
		q.Add(qf.apiName, v)
	}
	return nil
}

// queryEnum returns the enum declared on a query parameter's own schema, or nil.
func queryEnum(d *registry.OperationDetail, apiName string) []any {
	if p := findParam(d, apiName, "query"); p != nil {
		return p.Enum
	}
	return nil
}

// queryItemEnum returns the enum declared on an array query parameter's item
// schema, or nil. Array parameters constrain elements, not the whole list.
func queryItemEnum(d *registry.OperationDetail, apiName string) []any {
	if p := findParam(d, apiName, "query"); p != nil && p.Items != nil {
		return p.Items.Enum
	}
	return nil
}

func bindWorkspacePathHeader(rt *operationRuntime, pathValues []string, headers map[string]string) map[string]string {
	if !rt.pathFlagNames["workspace-id"] || findParam(rt.detail, "X-Workspace-ID", "header") == nil {
		return headers
	}
	for i, name := range rt.pathParams {
		if name == "workspace_id" {
			if headers == nil {
				headers = map[string]string{}
			}
			headers["X-Workspace-ID"] = pathValues[i]
		}
	}
	return headers
}

// buildHeaders assembles the per-request headers from spec-declared header
// flags the user explicitly set. Returns nil when none were set, so an omitted
// optional header stays absent from the wire.
//
// Enum vocabularies are deliberately NOT enforced here, and neither are they in
// validatePathArgs: the local enum gate covers query and body parameters only.
// No embedded spec declares an enum on a header or path parameter today, so a
// check here would be unreachable code; TestEnum_NoHeaderOrPathParamDeclaresEnum
// fails the build the day one does, which is the point at which the asymmetry
// stops being deliberate and has to be closed.
func buildHeaders(cobraCmd *cobra.Command, rt *operationRuntime) (map[string]string, *output.ExitError) {
	var headers map[string]string
	for flagName, hf := range rt.headerFlags {
		if !cobraCmd.Flags().Changed(flagName) {
			continue
		}
		if err := rejectEmptyRequiredValue("--"+flagName, *hf.strVal,
			paramRequired(rt.detail, hf.apiName, "header")); err != nil {
			return nil, err
		}
		// An explicitly blank replay key cannot identify an uncertain write.
		// Omitted optional headers remain absent for legacy shared operations.
		if strings.EqualFold(hf.apiName, "Idempotency-Key") {
			if err := ValidateIdempotencyKey("--"+flagName, *hf.strVal); err != nil {
				return nil, err
			}
		}
		if headers == nil {
			headers = map[string]string{}
		}
		headers[hf.apiName] = *hf.strVal
	}
	return headers, nil
}

// resolveBody constructs the JSON body. Empty when the op has neither --data
// nor any promoted fields. Explicit flags override --data fields.
//
// After merging --data with promoted flag values, this checks the resolved
// map against the operation's declared `required` list from the spec. Any
// required field that neither --data nor a flag supplied fails locally with
// a validation error rather than being forwarded as a partial write. This is
// the enforcement layer for both promoted primitives and object/array fields;
// registerBodyFlags only marks required fields in help text. Nested object and
// array requirements are validated recursively as well.
func resolveBody(f *cmdutil.Factory, cobraCmd *cobra.Command, rt *operationRuntime) (any, error) {
	if rt.bodyData == nil && len(rt.bodyFlags) == 0 {
		return nil, nil
	}

	base, err := readJSONBodyInput(f, rt.bodyData)
	if err != nil {
		return nil, err
	}

	if err := applyBodyFlags(cobraCmd, rt, base); err != nil {
		return nil, err
	}
	if err := applyLoopProjectBody(cobraCmd, rt, base); err != nil {
		return nil, err
	}
	if err := applyTaskAssigneeBody(cobraCmd, f, rt, base); err != nil {
		return nil, err
	}
	if err := applyGeneratedIdempotencyKey(rt, base); err != nil {
		return nil, err
	}

	if err := validateRequiredBodyFields(rt, base); err != nil {
		return nil, err
	}
	if err := validateBodyVariants(rt, base); err != nil {
		return nil, err
	}

	if len(base) == 0 {
		return nil, nil
	}
	return base, nil
}

func readJSONBodyInput(f *cmdutil.Factory, input *string) (map[string]any, error) {
	base := map[string]any{}

	if input != nil && *input != "" {
		raw, err := cmdutil.ParseInput(f, *input)
		if err != nil {
			return nil, output.ErrValidation(fmt.Sprintf("--data: %v", err), "pass inline JSON, @file, or @-")
		}
		if len(raw) > 0 {
			// UseNumber, not a plain Unmarshal: a plain decode turns every JSON
			// number into float64, which silently rounds a uint64 id above 2^53.
			// For a parent_id-style field that id selects a destination row, so a
			// rounded value is a *valid* id pointing somewhere the caller did not
			// ask for. json.Number keeps the caller's exact digits all the way to
			// the wire and lets the schema walker range-check them.
			dec := json.NewDecoder(bytes.NewReader(raw))
			dec.UseNumber()
			if err := dec.Decode(&base); err != nil {
				return nil, output.ErrValidation(fmt.Sprintf("--data is not a JSON object: %v", err), "expected a JSON object for this operation")
			}
			// JSON null is the one non-object shape that *decodes successfully* into a
			// map: it leaves base nil rather than failing. Every other non-object shape
			// (true, a number, a string, an array) fails in Decode above and was always
			// a clean validation error, which is why this is a nil check on success and
			// not another special case. Without it the promoted-flag merge below wrote
			// into a nil map and panicked — a Go stack trace on caller input, in the one
			// path whose purpose is to enforce the local contract — and `--data null`
			// with no promoted flag silently behaved like an absent body.
			if base == nil {
				return nil, output.ErrValidation("--data is not a JSON object: null",
					"expected a JSON object for this operation; omit --data to send no body")
			}
			// A Decoder stops after the first value where json.Unmarshal rejected
			// trailing bytes, so trailing content is checked explicitly to keep
			// --data exactly as strict as it was before UseNumber. The check is a
			// second Decode requiring io.EOF, not dec.More(): More reports whether
			// another element follows *inside the current array or object*, so at
			// top level it answers false for a stray "]" or "}" and let
			// `{"a":1}]` through.
			if err := dec.Decode(new(json.RawMessage)); !errors.Is(err, io.EOF) {
				return nil, output.ErrValidation("--data has trailing content after the JSON object",
					"pass exactly one JSON object for this operation")
			}
		}
	}

	return base, nil
}

func applyGeneratedIdempotencyKey(rt *operationRuntime, body map[string]any) error {
	if rt.detail == nil || rt.detail.AutoIdempotencyKey == "" {
		return nil
	}
	name := rt.detail.AutoIdempotencyKey
	if value, present := body[name]; present && !emptyAutoIdempotencyValue(value) {
		return nil
	}
	if len(rt.detail.BodyVariants) > 0 && !variantNeedsGeneratedField(rt.detail.BodyVariants, body, name) {
		return nil
	}
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return output.ErrWithHint("internal", "RANDOM_FAILED", fmt.Sprintf("generate idempotency key: %v", err), "retry the command")
	}
	body[name] = fmt.Sprintf("octo-cli-%x", key)
	return nil
}

func emptyAutoIdempotencyValue(value any) bool {
	if value == nil {
		return true
	}
	text, ok := value.(string)
	return ok && strings.TrimSpace(text) == ""
}

func variantNeedsGeneratedField(variants []registry.BodyVariant, body map[string]any, field string) bool {
	for _, variant := range variants {
		needsField, compatible := false, true
		for _, required := range variant.Required {
			if required == field {
				needsField = true
				continue
			}
			if value, present := body[required]; !present || missingVariantRequiredValue(value) {
				compatible = false
			}
		}
		for _, forbidden := range variant.Forbidden {
			if _, present := body[forbidden]; present {
				compatible = false
			}
		}
		if needsField && compatible {
			return true
		}
	}
	return false
}

func validateBodyVariants(rt *operationRuntime, body map[string]any) error {
	if rt.detail == nil || len(rt.detail.BodyVariants) == 0 {
		return nil
	}
	for _, variant := range rt.detail.BodyVariants {
		valid := true
		for _, name := range variant.Required {
			if value, exists := body[name]; !exists || missingVariantRequiredValue(value) {
				valid = false
			}
		}
		for _, name := range variant.Forbidden {
			if _, exists := body[name]; exists {
				valid = false
			}
		}
		if valid {
			return nil
		}
	}
	hint := rt.detail.BodyVariantsHint
	if hint == "" {
		hint = "provide the required fields for exactly one supported operation mode and omit fields forbidden in that mode"
	}
	return output.ErrValidation("request body does not match an allowed operation mode", hint)
}

// missingVariantRequiredValue treats a whitespace-only string as absent, the
// same definition emptyAutoIdempotencyValue uses. Diverging here classified
// slug:"   " as a republish and sent whitespace as a document reference.
func missingVariantRequiredValue(value any) bool {
	if value == nil {
		return true
	}
	text, ok := value.(string)
	return ok && strings.TrimSpace(text) == ""
}

// applyBodyFlags merges body-flag values (--foo, --bar) into base, following the
// promotable-primitive kinds registered on the operation. Explicit flags override
// --data; declared boolean defaults fill only absent body keys.
// uint64 id flags are validated and written as json.Number so they marshal as a
// bare JSON integer — the wire contract stays integer while the flag is text.
func applyBodyFlags(cobraCmd *cobra.Command, rt *operationRuntime, base map[string]any) *output.ExitError {
	for flagName, bf := range rt.bodyFlags {
		if !loopFlagChanged(cobraCmd, flagName) {
			if _, supplied := base[bf.apiName]; !supplied && bf.boolDefault != nil {
				base[bf.apiName] = *bf.boolDefault
			}
			continue
		}
		switch bf.kind {
		case kindInt:
			base[bf.apiName] = *bf.intVal
		case kindFloat64:
			base[bf.apiName] = *bf.floatVal
		case kindBool:
			base[bf.apiName] = *bf.boolVal
		case kindStringSlice:
			base[bf.apiName] = *bf.strSlc
		case kindUint64:
			n, err := output.ParseUint64Decimal("--"+flagName, *bf.strVal)
			if err != nil {
				return err
			}
			base[bf.apiName] = output.Uint64JSONNumber(n)
		default:
			base[bf.apiName] = *bf.strVal
		}
	}
	return nil
}

// validateRequiredBodyFields enforces the request schema against the merged
// body. It runs before the empty-body short-circuit so schema-required fields
// are checked even when no body values were supplied. Optional request bodies
// remain optional; if supplied, nested constraints and enum vocabularies still
// apply.
func validateRequiredBodyFields(rt *operationRuntime, base map[string]any) error {
	if rt.detail == nil || rt.detail.RequestBody == nil {
		return nil
	}
	// Multipart and raw-body uploads are assembled separately from base. Their
	// required binary part is validated by buildMultipartBody / buildRawBody.
	if rt.detail.Multipart || rt.detail.RawBody {
		return nil
	}
	enforcePublicAPIConstraints := rt.detail.Service == "loop" || rt.detail.StrictRequestSchema
	if len(base) == 0 && !rt.detail.RequestBodyRequired {
		return nil
	}
	v := bodySchemaValidator{
		flagFor:                     topLevelBodyFlagNames(rt),
		enforcePublicAPIConstraints: enforcePublicAPIConstraints,
	}
	if exitErr := v.validate(rt.detail.RequestBody, base, "", ""); exitErr != nil {
		return exitErr
	}
	return nil
}

// topLevelBodyFlagNames inverts the operation's body-flag table into
// wire-field → flag-name, so a validation error on a promoted field can name
// the flag the caller typed instead of the JSON key behind it.
func topLevelBodyFlagNames(rt *operationRuntime) map[string]string {
	if len(rt.bodyFlags) == 0 {
		return nil
	}
	out := make(map[string]string, len(rt.bodyFlags))
	for flagName, bf := range rt.bodyFlags {
		out[bf.apiName] = flagName
	}
	return out
}

// bodySchemaValidator walks a resolved request body against the operation's
// request schema, enforcing required fields, minItems and enum vocabularies
// before anything is sent. Loop additionally enforces the extended constraints
// retained from its Public API schema. It covers the merged body — promoted
// flags AND --data — because --data is not a raw passthrough on this path.
type bodySchemaValidator struct {
	flagFor                     map[string]string // wire field name → promoted flag name (top level only)
	enforcePublicAPIConstraints bool              // extended JSON Schema constraints (Loop or explicit service opt-in)
}

// validate reports the first violation found, or nil. Enum violations carry
// their own ENUM_NOT_ALLOWED code so an agent can branch on "value outside a
// closed set" without parsing the message; structural violations keep the
// historical VALIDATION_ERROR envelope byte-for-byte.
func (v bodySchemaValidator) validate(schema *registry.SchemaInfo, value any, path, flagName string) *output.ExitError {
	if v.enforcePublicAPIConstraints {
		if err := v.validateComposition(schema, value, path, flagName); err != nil {
			return err
		}
	}
	if err := checkEnum(enumFieldLabel(path, flagName), value, schema.Enum); err != nil {
		if schema.EnumHint != "" {
			err.Hint += ". " + schema.EnumHint
		}
		return err
	}
	if err := checkUint64Field(schema, value, path, flagName); err != nil {
		return err
	}
	if value == nil && (!v.enforcePublicAPIConstraints || schema.Type != "boolean") {
		// Enum constraints and non-nullable uint64 constraints have been checked
		// above. Other optional fields preserve historical null passthrough.
		return nil
	}
	return v.validateByType(schema, value, path, flagName)
}

func (v bodySchemaValidator) validateByType(
	schema *registry.SchemaInfo,
	value any,
	path, flagName string,
) *output.ExitError {
	switch schema.Type {
	case "object":
		return v.validateObject(schema, value, path)
	case "array":
		return v.validateArray(schema, value, path, flagName)
	case "integer", "number":
		if v.enforcePublicAPIConstraints {
			return validateNumber(schema, value, path)
		}
	case "string":
		if v.enforcePublicAPIConstraints {
			return validateString(schema, value, path)
		}
	case "boolean":
		if v.enforcePublicAPIConstraints {
			return validateBoolean(value, path)
		}
	case "":
		if v.enforcePublicAPIConstraints {
			if len(schema.Required) > 0 || len(schema.Properties) > 0 {
				return v.validateObject(schema, value, path)
			}
			if schema.MinLength > 0 || schema.MaxLength > 0 {
				return validateString(schema, value, path)
			}
		}
	}
	return nil
}

func validateBoolean(value any, path string) *output.ExitError {
	if _, valid := value.(bool); !valid {
		return schemaError(fmt.Sprintf("field %s must have type boolean", bodyPath(path)))
	}
	return nil
}

// Compare exact JSON decimals, preserving integers above the float64 precision limit.
func validateNumber(schema *registry.SchemaInfo, value any, path string) *output.ExitError {
	switch value.(type) {
	case json.Number, int, int64, uint64, float64:
	default:
		return schemaError(fmt.Sprintf("field %s must have type %s", bodyPath(path), schema.Type))
	}
	raw, err := json.Marshal(value)
	if err != nil {
		return schemaError(fmt.Sprintf("field %s must be a finite number", bodyPath(path)))
	}
	n, ok := new(big.Rat).SetString(string(raw))
	if !ok || (schema.Type == "integer" && !n.IsInt()) {
		return schemaError(fmt.Sprintf("field %s must have type %s", bodyPath(path), schema.Type))
	}
	for _, bound := range []struct {
		value   *float64
		minimum bool
	}{{schema.Minimum, true}, {schema.Maximum, false}} {
		if bound.value == nil {
			continue
		}
		b, ok := new(big.Rat).SetString(strconv.FormatFloat(*bound.value, 'g', -1, 64))
		if !ok {
			continue
		}
		comparison := n.Cmp(b)
		if (bound.minimum && comparison < 0) || (!bound.minimum && comparison > 0) {
			return schemaError(fmt.Sprintf("field %s is outside its allowed numeric range", bodyPath(path)))
		}
	}
	return nil
}

func (v bodySchemaValidator) validateComposition(
	schema *registry.SchemaInfo,
	value any,
	path, flagName string,
) *output.ExitError {
	if schema.Const != nil {
		if err := checkEnum(enumFieldLabel(path, flagName), value, []any{schema.Const}); err != nil {
			return schemaError(fmt.Sprintf("field %s must equal the declared constant", bodyPath(path)))
		}
	}
	if err := v.validateOneOf(schema.OneOf, value, path, flagName); err != nil {
		return err
	}
	return v.validateAnyOf(schema.AnyOf, value, path, flagName)
}

func (v bodySchemaValidator) validateOneOf(
	schemas []registry.SchemaInfo,
	value any,
	path, flagName string,
) *output.ExitError {
	if len(schemas) == 0 {
		return nil
	}
	matches := 0
	for i := range schemas {
		if v.validate(&schemas[i], value, path, flagName) == nil {
			matches++
		}
	}
	if matches != 1 {
		return schemaError(fmt.Sprintf("field %s must match exactly one allowed schema", bodyPath(path)))
	}
	return nil
}

func (v bodySchemaValidator) validateAnyOf(
	schemas []registry.SchemaInfo,
	value any,
	path, flagName string,
) *output.ExitError {
	if len(schemas) == 0 {
		return nil
	}
	for i := range schemas {
		if v.validate(&schemas[i], value, path, flagName) == nil {
			return nil
		}
	}
	return schemaError(fmt.Sprintf("field %s must match at least one allowed schema", bodyPath(path)))
}

func validateString(schema *registry.SchemaInfo, value any, path string) *output.ExitError {
	text, ok := value.(string)
	if !ok {
		return schemaError(fmt.Sprintf("field %s must be a string", bodyPath(path)))
	}
	length := utf8.RuneCountInString(text)
	if schema.MinLength > 0 && length < schema.MinLength {
		return schemaError(fmt.Sprintf("field %s must contain at least %d character(s)", bodyPath(path), schema.MinLength))
	}
	if schema.MaxLength > 0 && length > schema.MaxLength {
		return schemaError(fmt.Sprintf("field %s must contain at most %d character(s)", bodyPath(path), schema.MaxLength))
	}
	return nil
}

// checkUint64Field range-checks a body field the spec marks `format: uint64`.
// The promoted-flag path validates through ParseUint64Decimal before the value
// is ever placed in the body; this is the same check for a value that arrived
// through --data, at whatever nesting depth, so the lossless-id contract does
// not hold on one input path and lapse on the other.
//
// A non-numeric JSON value is rejected rather than forwarded: the wire contract
// for these fields is a JSON integer, so a quoted id would come back as a
// backend decode error naming a server struct. The message names the promoted
// flag when there is one, which is the decimal-string surface a caller reaching
// for a string actually wants.
//
// A null is rejected unless the schema's type explicitly includes null. This is
// separate from enum validation: an enum-constrained nullable field still needs
// null among its enum members before it can pass the earlier enum gate.
func checkUint64Field(schema *registry.SchemaInfo, value any, path, flagName string) *output.ExitError {
	if schema.Format != uint64Format {
		return nil
	}
	label := enumFieldLabel(path, flagName)
	if value == nil {
		if schema.Nullable {
			return nil
		}
		return output.ErrValidation(
			fmt.Sprintf("%s must be a JSON integer uint64 id, got null", label),
			"omit the field to take the backend default, or pass the id as a bare JSON number with digits only")
	}
	num, ok := value.(json.Number)
	if !ok {
		return output.ErrValidation(
			fmt.Sprintf("%s must be a JSON integer uint64 id, got %T", label, value),
			"pass the id as a bare JSON number with digits only, or use the matching flag which accepts it as a decimal string")
	}
	_, err := output.ParseUint64Decimal(label, num.String())
	return err
}

func (v bodySchemaValidator) validateObject(schema *registry.SchemaInfo, value any, path string) *output.ExitError {
	obj, ok := value.(map[string]any)
	if !ok || obj == nil {
		return schemaError(fmt.Sprintf("field %s must be an object", bodyPath(path)))
	}
	if err := v.validateRequiredProperties(schema, obj, path); err != nil {
		return err
	}
	if err := v.validateObjectConstraints(schema, obj, path); err != nil {
		return err
	}
	for name := range schema.Properties {
		// Walk present nulls too: the child schema decides whether null is a valid
		// clearing value or a constraint violation.
		if child, exists := obj[name]; exists {
			childSchema := schema.Properties[name]
			// Only root-level fields have a promoted flag; a nested field of the
			// same name is --data-only and must not borrow that flag's label.
			childFlag := ""
			if path == "" {
				childFlag = v.flagFor[name]
			}
			if err := v.validate(&childSchema, child, joinBodyPath(path, name), childFlag); err != nil {
				return err
			}
		}
	}
	return nil
}

func (v bodySchemaValidator) validateRequiredProperties(
	schema *registry.SchemaInfo,
	obj map[string]any,
	path string,
) *output.ExitError {
	var missing []string
	for _, name := range schema.Required {
		child, exists := obj[name]
		if !exists || child == nil {
			missing = append(missing, joinBodyPath(path, name))
		}
	}
	if len(missing) > 0 {
		return schemaError(fmt.Sprintf("is missing required field(s): %s", strings.Join(missing, ", ")))
	}
	return nil
}

func (v bodySchemaValidator) validateObjectConstraints(
	schema *registry.SchemaInfo,
	obj map[string]any,
	path string,
) *output.ExitError {
	if !v.enforcePublicAPIConstraints {
		return nil
	}
	if schema.MinProperties > 0 && len(obj) < schema.MinProperties {
		if path == "" && schema.MinProperties == 1 {
			return schemaError("must provide at least one field to update")
		}
		return schemaError(fmt.Sprintf("field %s must contain at least %d field(s)",
			bodyPath(path), schema.MinProperties))
	}
	if schema.AdditionalProperties == nil || *schema.AdditionalProperties {
		return nil
	}
	unknown := make([]string, 0)
	for name := range obj {
		if _, declared := schema.Properties[name]; !declared {
			unknown = append(unknown, joinBodyPath(path, name))
		}
	}
	if len(unknown) == 0 {
		return nil
	}
	sort.Strings(unknown)
	return schemaError(fmt.Sprintf("contains unknown field(s): %s", strings.Join(unknown, ", ")))
}

func (v bodySchemaValidator) validateArray(schema *registry.SchemaInfo, value any, path, flagName string) *output.ExitError {
	items, ok := bodyArray(value)
	if !ok {
		return schemaError(fmt.Sprintf("field %s must be an array", bodyPath(path)))
	}
	if schema.MinItems > 0 && len(items) < schema.MinItems {
		return schemaError(fmt.Sprintf("field %s must contain at least %d item(s)", bodyPath(path), schema.MinItems))
	}
	if v.enforcePublicAPIConstraints && schema.MaxItems > 0 && len(items) > schema.MaxItems {
		return schemaError(fmt.Sprintf("field %s must contain at most %d item(s)", bodyPath(path), schema.MaxItems))
	}
	if schema.Items == nil {
		return nil
	}
	// Elements come from the same flag as the array itself (a repeated flag), so
	// they keep its label; the rejected value in the message identifies which one.
	for i, item := range items {
		if err := v.validate(schema.Items, item, fmt.Sprintf("%s[%d]", path, i), flagName); err != nil {
			return err
		}
	}
	return nil
}

// schemaError wraps a structural violation in the historical request-body
// validation envelope.
func schemaError(issue string) *output.ExitError {
	return output.ErrValidation(
		fmt.Sprintf("request body %s", issue),
		"pass values that satisfy the operation schema via --data JSON or matching body flags")
}

func bodyArray(value any) ([]any, bool) {
	switch items := value.(type) {
	case []any:
		return items, true
	case []string:
		out := make([]any, len(items))
		for i := range items {
			out[i] = items[i]
		}
		return out, true
	default:
		return nil, false
	}
}

func joinBodyPath(parent, child string) string {
	if parent == "" {
		return child
	}
	return parent + "." + child
}

func bodyPath(path string) string {
	if path == "" {
		return "<root>"
	}
	return path
}

// emitOnce runs one request and emits the envelope. Returns the same error
// value so cobra sets a non-zero exit code.
func emitOnce(ctx context.Context, f *cmdutil.Factory, rt *operationRuntime, req *client.Request) error {
	cli, err := f.ClientForCredential(ctx, req.Credential)
	if err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	body, err := cli.Do(ctx, req)
	if err != nil {
		err = annotateSheetCleaningError(rt, req, err)
		err = annotateIdempotencyKey(rt, req, err)
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	if f.Globals == nil || !f.Globals.DryRun {
		if contractErr := validateSheetReadScope(body, rt, req); contractErr != nil {
			return emitAndReturn(f, contractErr)
		}
		if contractErr := validateReadResponse(body, rt); contractErr != nil {
			return emitAndReturn(f, contractErr)
		}
	}
	body, err = normalizeResponse(f, rt, body)
	if err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	if req.ResponseUnwrap != "" && (f.Globals == nil || !f.Globals.DryRun) {
		body, err = unwrapResponse(body, req.ResponseUnwrap, req.UnwrapRequiredFields, rt.detail.ResponseSchema)
		if err != nil {
			// A malformed 2xx means the request reached the server carrying the
			// key, so the create may be committed — the same ambiguity a 5xx
			// has, and the key is the only handle on the resulting orphan. The
			// hint is left empty so annotateIdempotencyKey can supply the
			// retry-with-this-key wording it reserves for an unknown outcome;
			// the fallback covers an operation with required unwrap fields but
			// no auto key, where there is no key to retry with.
			unwrapErr := annotateIdempotencyKey(rt, req, output.ErrWithHint("internal", "RESPONSE_UNWRAP", err.Error(), ""))
			if exit := output.AsExitError(unwrapErr); exit != nil && exit.Hint == "" {
				exit.Hint = "backend response did not match its operation spec"
			}
			_ = f.EmitError(unwrapErr) //nolint:errcheck // best-effort emit before returning err
			return unwrapErr
		}
	}
	if req.Service == "loop" {
		return f.EmitSuccessWithMeta(body, output.EnvelopeMeta{UnwrapResource: true})
	}
	return f.EmitSuccess(body)
}

// annotateIdempotencyKey records the key a failed create was sent with, so a
// caller whose outcome is unknown can retry the SAME creation instead of
// minting a second document. Without it the generated key dies with the process
// and an orphan created by a committed-but-unacknowledged request is
// unreachable: the caller never received its doc reference, so it can neither
// address nor delete it.
//
// The key always lands in Detail — that is what makes the orphan recoverable,
// and it costs nothing on a definite refusal. The hint is only rewritten when
// the outcome is genuinely ambiguous (transport failure, timeout, 5xx) AND no
// hint was set: a 4xx created nothing, so claiming "outcome unknown" there
// would be false, and clobbering a curated hint like "ask a Workspace owner to
// add this Bot" replaces actionable guidance with a misleading retry.
func annotateIdempotencyKey(rt *operationRuntime, req *client.Request, err error) error {
	field, key := requestIdempotencyKey(rt, req)
	if key == "" {
		return err
	}
	var exit *output.ExitError
	if !errors.As(err, &exit) {
		return err
	}
	merged := map[string]json.RawMessage{}
	if len(exit.Detail) > 0 {
		// A non-object payload is kept intact under a sibling key.
		if json.Unmarshal(exit.Detail, &merged) != nil {
			merged = map[string]json.RawMessage{"response": exit.Detail}
		}
	}
	if _, taken := merged[field]; taken {
		return err
	}
	quoted, marshalErr := json.Marshal(key)
	if marshalErr != nil {
		return err
	}
	merged[field] = quoted
	detail, marshalErr := json.Marshal(merged)
	if marshalErr != nil {
		return err
	}
	exit.Detail = detail
	if exit.Hint == "" && exit.OutcomeUnknown() {
		exit.Hint = fmt.Sprintf("outcome unknown: retry with --%s %s with the same body to resume the same operation rather than duplicate it",
			strings.ReplaceAll(field, "_", "-"), key)
	}
	return exit
}

// verifiedReplayDedup lists the operations whose backend is verified to
// deduplicate every resend of the same request carrying the same idempotency
// key, whatever resource it targets. Only these POSTs are resent after an
// attempt that may have taken effect. An operation is absent when its key is
// honoured only for some resources (docs.create, docs.comments.add and the
// docs.versions writes: octo-docs-backend reads Idempotency-Key on html_ppt
// paths only and ignores it for every other document type) or when its backend
// contract has not been verified (summary.create, html.publish and
// html.draft.create).
var verifiedReplayDedup = map[string]bool{
	// octo-fleet CreateCapabilityInstallation requires the key and claims it in
	// capability_installation_receipt (primary key workspace, owner, key) inside
	// the install transaction; a repeat within 24 hours replays the stored
	// receipt, and a different request under the same key is refused with 409.
	"capability.install": true,
}

// replayDeduplicated reports whether req may be resent after an ambiguous
// failure: its operation has a verified deduplication contract and the request
// carries a key.
func replayDeduplicated(rt *operationRuntime, req *client.Request) bool {
	if rt == nil || rt.detail == nil || !verifiedReplayDedup[rt.detail.ID] {
		return false
	}
	_, key := requestIdempotencyKey(rt, req)
	return strings.TrimSpace(key) != ""
}

func requestIdempotencyKey(rt *operationRuntime, req *client.Request) (field, key string) {
	if rt == nil || rt.detail == nil || req == nil {
		return "", ""
	}
	field = rt.detail.AutoIdempotencyKey
	if field != "" {
		if body, ok := req.Body.(map[string]any); ok {
			key, _ = body[field].(string)
		}
	} else {
		// Header replay keys are explicitly declared metadata, never inferred from
		// arbitrary request fields. Preserve them for malformed 2xx responses too.
		for i := range rt.detail.Parameters {
			param := &rt.detail.Parameters[i]
			if param.In == "header" && strings.EqualFold(param.Name, "Idempotency-Key") && param.FlagName == "idempotency-key" {
				field = "idempotency_key"
				key = req.Headers[param.Name]
				break
			}
		}
	}
	return field, key
}

// unwrapResponse lifts the spec-declared field out of a successful response.
// It fails OPEN: an empty body, or a body without the field, passes through
// unchanged. The server itself always writes an envelope, so this is not about
// its own shape — it protects the case where a misconfigured intermediary
// answers 200 with something else after the server already committed. Failing
// closed there reports a completed delete/grant/comment as ok:false, and a
// caller that retries on that can duplicate work.
//
// It still fails closed when the value cannot carry what the caller was told to
// read from it: when the 2xx schema declares required properties, an absent
// field, a null, a scalar, or an object missing those keys all yield an empty
// reference. Required values must match their declared JSON types.
func unwrapResponse(body []byte, path string, required []string, schema *registry.SchemaInfo) ([]byte, error) {
	if len(bytes.TrimSpace(body)) == 0 {
		if len(required) > 0 {
			return nil, fmt.Errorf("response is empty but %q must carry %s", path, strings.Join(required, ", "))
		}
		return body, nil
	}
	raw, found, err := rawValueAtPath(body, path)
	if err != nil || !found {
		if len(required) > 0 {
			return nil, fmt.Errorf("response is missing field %q carrying %s", path, strings.Join(required, ", "))
		}
		return body, nil //nolint:nilerr // deliberate fail-open; see doc comment
	}
	if len(required) > 0 {
		var object map[string]json.RawMessage
		if jsonErr := json.Unmarshal(raw, &object); jsonErr != nil || object == nil {
			return nil, fmt.Errorf("response field %q must be an object carrying %s", path, strings.Join(required, ", "))
		}
		schema = registry.ResponsePayloadSchema(schema, path)
		for _, name := range required {
			value, ok := object[name]
			if !ok {
				return nil, fmt.Errorf("response field %q is missing required %q", path, name)
			}
			if schema == nil || unusableUnwrapValue(value, schema.Properties[name].Type) {
				return nil, fmt.Errorf("response field %q carries an unusable %q", path, name)
			}
		}
	}
	return raw, nil
}

// unusableUnwrapValue checks the declared top-level payload type. Empty arrays,
// objects, false and zero are valid; required string references remain nonblank.
// Advisory strings such as contentHash must not be marked required: an absent
// digest must not hide a committed edit receipt. The registry tests cover both
// unwrap and strict-response required-field types.
func unusableUnwrapValue(raw json.RawMessage, kind string) bool {
	if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		return true
	}
	switch kind {
	case "string":
		var value string
		return json.Unmarshal(raw, &value) != nil || strings.TrimSpace(value) == ""
	case "integer":
		decoder := json.NewDecoder(bytes.NewReader(raw))
		decoder.UseNumber()
		var value any
		if decoder.Decode(&value) != nil {
			return true
		}
		number, ok := value.(json.Number)
		return !ok || strings.ContainsAny(string(number), ".eE")
	case "number":
		var value float64
		return json.Unmarshal(raw, &value) != nil
	case "boolean":
		var value bool
		return json.Unmarshal(raw, &value) != nil
	case "object":
		var value map[string]json.RawMessage
		return json.Unmarshal(raw, &value) != nil || value == nil
	case "array":
		var value []json.RawMessage
		return json.Unmarshal(raw, &value) != nil || value == nil
	default:
		return true
	}
}

// normalizeResponse applies the operation's spec-declared output transforms
// (x-octo-response-fields, x-octo-lossless-id-fields). It is skipped under
// --dry-run, where the body is the CLI's own request description rather than a
// backend DTO, and is a no-op for operations declaring neither extension.
func normalizeResponse(f *cmdutil.Factory, rt *operationRuntime, body []byte) ([]byte, error) {
	if rt == nil || rt.detail == nil {
		return body, nil
	}
	if f.Globals != nil && f.Globals.DryRun {
		return body, nil
	}
	out, err := output.NormalizeResponse(body, rt.detail.ResponseFieldAliases, rt.detail.LosslessIDFields)
	if err != nil {
		return nil, output.ErrWithHint("internal", "RESPONSE_NORMALIZE", err.Error(), "report the unexpected response shape")
	}
	return out, nil
}

func writeOnlyBodyFields(schema *registry.SchemaInfo) []string {
	if schema == nil {
		return nil
	}
	var fields []string
	for name := range schema.Properties {
		if schema.Properties[name].WriteOnly {
			fields = append(fields, name)
		}
	}
	return fields
}

// --- pagination ---

// runPaginated walks pages until has_more is false, --page-limit is hit, or
// the context is cancelled. The merged result is a flat array of all data
// items — the caller gets a single envelope with no _pagination block
// (architecture §4.4).
func runPaginated(ctx context.Context, f *cmdutil.Factory, rt *operationRuntime, firstReq *client.Request) error {
	// Pagination and binary output-to-disk are mutually exclusive. The loop
	// reuses OutputPath for every page, so an operation that was both paginated
	// AND declared an inline binary body would write each page to the same file,
	// leaving only the last page's bytes. No spec op declares both today, so this
	// never fires in practice; it is a fail-loud guard against a future spec that
	// wires the two together and would otherwise silently corrupt --output.
	if err := validatePaginationRequest(firstReq); err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	// Pagination and the spec-declared output transforms are likewise mutually
	// exclusive: the merged pages are emitted below without going through
	// normalizeResponse, so an operation declaring both would answer the same
	// call with two different response contracts depending on --page-all. Refused
	// here rather than transformed per page — the transforms rewrite field names
	// and id representations, and a per-page rewrite would have to prove it never
	// touches the cursor the loop reads back.
	if err := validatePaginationTransforms(rt); err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}

	cli, err := f.ClientForCredential(ctx, firstReq.Credential)
	if err != nil {
		_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
		return err
	}
	pag := rt.detail.Pagination
	cursorParam, limit := paginationControls(rt, pag)
	merged := make([]json.RawMessage, 0, 64)
	req := *firstReq
	seenCursors := paginationSeenCursors(&req, rt, pag, cursorParam)
	for page := 0; page < limit; page++ {
		body, err := cli.Do(ctx, &req)
		if err != nil {
			_ = f.EmitError(err) //nolint:errcheck // best-effort emit before returning err
			return err
		}
		if contractErr := validateReadResponse(body, rt); contractErr != nil {
			return emitAndReturn(f, contractErr)
		}
		data, nextCursor, hasMore, perr := parsePage(body, pag)
		if perr != nil {
			_ = f.EmitError(perr) //nolint:errcheck // best-effort emit before returning err
			return perr
		}
		merged = append(merged, data...)
		if !hasMore || nextCursor == "" || page+1 >= limit {
			break
		}
		if cursorWasSeen(seenCursors, nextCursor) {
			loopErr := paginationLoopError(nextCursor)
			_ = f.EmitError(loopErr) //nolint:errcheck // best-effort emit before returning err
			return loopErr
		}
		if seenCursors != nil {
			seenCursors[nextCursor] = struct{}{}
		}
		req = requestWithCursor(&req, rt, cursorParam, nextCursor)
	}

	out, err := json.Marshal(merged)
	if err != nil {
		return err
	}
	return f.EmitSuccess(out)
}

func paginationControls(rt *operationRuntime, pag *registry.PaginationInfo) (cursorParam string, limit int) {
	cursorParam = pag.CursorParam
	if cursorParam == "" {
		cursorParam = "cursor"
	}
	limit = 10
	if rt.pageLimit != nil && *rt.pageLimit > 0 {
		limit = *rt.pageLimit
	}
	return cursorParam, limit
}

// Opt-in read contracts reject missing data instead of reporting an empty list.
// Existing mutation responses retain their historical delivery semantics.
func validateReadResponse(body []byte, rt *operationRuntime) *output.ExitError {
	if rt == nil || rt.detail == nil || !rt.detail.StrictResponseSchema {
		return nil
	}
	schema := rt.detail.ResponseSchema
	var payload map[string]json.RawMessage
	if schema == nil || json.Unmarshal(body, &payload) != nil || payload == nil {
		return output.ErrWithHint("internal", "RESPONSE_SCHEMA", "backend response must be an object", "backend response did not match its operation spec")
	}
	for _, name := range schema.Required {
		raw, ok := payload[name]
		if !ok || unusableUnwrapValue(raw, schema.Properties[name].Type) {
			return output.ErrWithHint("internal", "RESPONSE_SCHEMA", fmt.Sprintf("backend response is missing or has invalid %q", name), "no complete result was returned")
		}
	}
	return nil
}

func paginationSeenCursors(req *client.Request, rt *operationRuntime, pag *registry.PaginationInfo, cursorParam string) map[string]struct{} {
	if !pag.RejectCursorRepeats {
		return nil
	}
	return initialSeenCursors(req, rt, cursorParam)
}

func validatePaginationRequest(req *client.Request) *output.ExitError {
	if req.OutputPath == "" {
		return nil
	}
	return output.ErrWithHint(
		"internal",
		"PAGINATION_OUTPUT_CONFLICT",
		"operation is paginated and also writes a binary body to --output; these are mutually exclusive",
		"operation-spec bug: an op with x-octo-pagination must not also declare an inline 2xx binary body",
	)
}

// The page-all walker bypasses normalizeResponse and unwrapResponse; combining
// either transform with pagination would produce different output contracts.
// TestPagination_NoSpecPairsWithOutputTransforms guards the embedded specs.
func validatePaginationTransforms(rt *operationRuntime) *output.ExitError {
	if rt == nil || rt.detail == nil {
		return nil
	}
	if len(rt.detail.ResponseFieldAliases) == 0 && len(rt.detail.LosslessIDFields) == 0 &&
		rt.detail.ResponseUnwrap == "" {
		return nil
	}
	return output.ErrWithHint(
		"internal",
		"PAGINATION_TRANSFORM_CONFLICT",
		"response unwrap, field aliases and lossless ID transforms cannot be combined with pagination",
		"operation-spec bug: remove response transforms from paginated operations",
	)
}

func cursorWasSeen(seen map[string]struct{}, cursor string) bool {
	if seen == nil || cursor == "" {
		return false
	}
	_, ok := seen[cursor]
	return ok
}

func paginationLoopError(cursor string) *output.ExitError {
	return output.ErrWithHint(
		"internal",
		"PAGINATION_LOOP",
		fmt.Sprintf("backend repeated pagination cursor %q", cursor),
		"retry without --page-all or report the backend cursor loop",
	)
}

// requestWithCursor copies the whole request so no field is silently dropped.
// It clones the query/body container before setting the cursor, leaving the
// previous page's request unchanged.
func requestWithCursor(req *client.Request, rt *operationRuntime, cursorParam, cursor string) client.Request {
	next := *req
	if cursorIsQueryParam(rt, cursorParam) {
		nextQ := url.Values{}
		for key, values := range req.Query {
			nextQ[key] = append([]string(nil), values...)
		}
		nextQ.Set(cursorParam, cursor)
		next.Query = nextQ
	} else {
		next.Body = withCursorBody(req.Body, cursorParam, cursor)
	}
	return next
}

// cursorIsQueryParam reports whether this operation declares its pagination
// cursor as a URL query parameter (GET endpoints, e.g. matter.list) rather than
// a JSON body field (POST endpoints, e.g. the message.search family). The spec
// binds a query-declared cursor to a queryFlag whose apiName is the cursor
// param; a body-declared cursor has no such binding.
func cursorIsQueryParam(rt *operationRuntime, cursorParam string) bool {
	for _, qf := range rt.queryFlags {
		if qf.apiName == cursorParam {
			return true
		}
	}
	return false
}

// initialSeenCursors seeds the repeated-cursor guard with the cursor already
// carried by the first request. This prevents --cursor C --page-all from
// requesting C twice when a backend incorrectly returns C as its own next cursor.
func initialSeenCursors(req *client.Request, rt *operationRuntime, cursorParam string) map[string]struct{} {
	seen := map[string]struct{}{}
	if cursor := requestCursor(req, rt, cursorParam); cursor != "" {
		seen[cursor] = struct{}{}
	}
	return seen
}

func requestCursor(req *client.Request, rt *operationRuntime, cursorParam string) string {
	if cursorIsQueryParam(rt, cursorParam) {
		return req.Query.Get(cursorParam)
	}
	if body, ok := req.Body.(map[string]any); ok {
		if cursor, ok := body[cursorParam].(string); ok {
			return cursor
		}
	}
	return ""
}

// withCursorBody returns a shallow clone of the JSON body map with the cursor
// key set to nextCursor, so paging never mutates the previous page's body. A nil
// or non-map body yields a fresh single-key map (search bodies are always
// map[string]any from resolveBody).
func withCursorBody(body any, cursorParam, nextCursor string) map[string]any {
	next := map[string]any{}
	if m, ok := body.(map[string]any); ok {
		for k, v := range m {
			next[k] = v
		}
	}
	next[cursorParam] = nextCursor
	return next
}

// parsePage extracts pagination fields using x-octo-pagination paths. Defaults
// preserve the historical {data, pagination:{has_more,next_cursor}} contract.
// Specs without a has-more field must explicitly opt into cursor inference.
func parsePage(body []byte, pag *registry.PaginationInfo) (items []json.RawMessage, cursor string, hasMore bool, exitErr *output.ExitError) {
	if len(body) == 0 {
		return nil, "", false, nil
	}
	fields := paginationFieldsFor(pag)
	items, err := parsePageItems(body, fields.items)
	if err != nil {
		return nil, "", false, paginationParseError(err)
	}
	cursor, err = parsePageCursor(body, fields.cursor)
	if err != nil {
		return nil, "", false, paginationParseError(err)
	}
	if fields.inferHasMore {
		return items, cursor, cursor != "", nil
	}
	hasMore, err = parsePageHasMore(body, fields.hasMore)
	if err != nil {
		return nil, "", false, paginationParseError(err)
	}
	return items, cursor, hasMore, nil
}

type paginationFields struct {
	items        string
	cursor       string
	hasMore      string
	inferHasMore bool
}

func paginationFieldsFor(pag *registry.PaginationInfo) paginationFields {
	fields := paginationFields{items: "data", cursor: "pagination.next_cursor", hasMore: "pagination.has_more"}
	if pag == nil {
		return fields
	}
	if pag.ItemsField != "" {
		fields.items = pag.ItemsField
	}
	if pag.CursorField != "" {
		fields.cursor = pag.CursorField
	}
	if pag.HasMoreField != "" {
		fields.hasMore = pag.HasMoreField
	}
	fields.inferHasMore = pag.InferHasMore
	return fields
}

func parsePageItems(body []byte, path string) ([]json.RawMessage, error) {
	raw, found, err := rawValueAtPath(body, path)
	if err != nil || !found {
		return nil, err
	}
	var items []json.RawMessage
	if err := json.Unmarshal(raw, &items); err != nil {
		return nil, fmt.Errorf("field %q must be an array: %w", path, err)
	}
	return items, nil
}

func parsePageCursor(body []byte, path string) (string, error) {
	raw, found, err := rawValueAtPath(body, path)
	if err != nil || !found || string(raw) == "null" {
		return "", err
	}
	var cursor string
	if err := json.Unmarshal(raw, &cursor); err != nil {
		// Numeric cursors (including PPT comment IDs and version sequences)
		// retain their decimal representation without float64 rounding.
		// This parser is shared across all paginated operations.
		value := string(raw)
		if value != "" && strings.IndexFunc(value, func(r rune) bool { return r < '0' || r > '9' }) == -1 {
			return value, nil
		}
		return "", fmt.Errorf("field %q must be a string, unsigned integer or null: %w", path, err)
	}
	return cursor, nil
}

func parsePageHasMore(body []byte, path string) (bool, error) {
	raw, found, err := rawValueAtPath(body, path)
	if err != nil || !found || string(raw) == "null" {
		return false, err
	}
	var hasMore bool
	if err := json.Unmarshal(raw, &hasMore); err != nil {
		return false, fmt.Errorf("field %q must be a boolean or null: %w", path, err)
	}
	return hasMore, nil
}

func paginationParseError(err error) *output.ExitError {
	return output.ErrWithHint("internal", "PAGINATION_PARSE", err.Error(), "response did not match expected pagination shape")
}

// rawValueAtPath resolves dot-separated object keys while retaining the exact
// JSON bytes of the selected value. Literal dots in response keys are not
// supported by x-octo-pagination paths.
func rawValueAtPath(body []byte, path string) (raw json.RawMessage, found bool, err error) {
	if path == "" {
		return nil, false, nil
	}
	current := json.RawMessage(body)
	for _, part := range strings.Split(path, ".") {
		var object map[string]json.RawMessage
		if err := json.Unmarshal(current, &object); err != nil {
			return nil, false, fmt.Errorf("field path %q traverses a non-object: %w", path, err)
		}
		next, ok := object[part]
		if !ok {
			return nil, false, nil
		}
		current = next
	}
	return current, true, nil
}
