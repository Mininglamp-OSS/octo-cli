# octo-docs — Common features (comments, versions, members, attachments)

Read this for shared document management, versions, and document/sheet/board
comments. Comment anchors vary by type: document text range, sheet cell, board
point or element(s), or PPT document/slide/element/normalized position. Read
`ppt.md` for PPT comment commands/details, versions, export, and media.
Jump to the section you need:

- [Comments](#comments) — add/list/reply/resolve; anchors vary by type: doc text range, sheet cell, board point/elements, or PPT document/slide/element/position
- [Versions](#versions) — snapshot / preview / rename / delete / restore
- [Members & sharing](#members--sharing) — roles, forward-grant
- [Attachments](#attachments) — presign/upload local bytes and ingest external images

All commands call `$OCTO_API_BASE_URL/v1/bot/docs/*`. Auth & space rules are in
`SKILL.md`.

---

## Comments

Comments live out-of-band from the body and use type-specific anchors: a text
range (docs), a cell (sheets), a canvas point or element(s) (boards), or the
document, slide, element, or normalized point (PPT; see `ppt.md`).

```bash
# List thread roots + replies. --includeResolved 1 also returns resolved threads.
octo-cli docs comments list <docId> [--includeResolved 1] [--cursor <id>] [--limit 50]

# Read a comment and its authoritative root anchor (replies inherit root.anchor).
octo-cli docs comments get <docId> <commentId>

# Replies return up to 25 items with nextCursor; pass it as --cursor or use --page-all.
octo-cli docs comments replies <docId> <rootId> [--cursor <id>] [--page-all]

# Root comment: needs an anchor. With a live editor selection, pass the opaque
# base64 Yjs positions. Without one (a bot), pass --anchorText and the backend
# resolves it to an anchor.
octo-cli docs comments add <docId> \
  --body "Please clarify this" \
  --anchorStart <base64> --anchorEnd <base64> [--anchorText "the quoted span"]

# Bot root comment (no live positions): anchor by text. Disambiguate a text that
# appears more than once with --blockPath (comma-separated child-index path) and
# --occurrence (1-based match index); an ambiguous match returns 422.
octo-cli docs comments add <docId> \
  --body "Please clarify this" --anchorText "the quoted span" \
  [--blockPath "0,2"] [--occurrence 2]

# Reply to a thread root: set --parentId, omit anchors.
octo-cli docs comments add <docId> --body "Agreed" --parentId <rootId>

# Edit your own comment's text, OR resolve/reopen a thread root (pass one).
octo-cli docs comments edit   <docId> <id> --body "edited text"
octo-cli docs comments edit   <docId> <id> --resolved=true      # writer; false reopens

octo-cli docs comments delete <docId> <id>          # soft delete (author)
octo-cli docs comments delete <docId> <id> --hard 1 # hard delete (admin)
```

`docs comments list` is cursor-based; pass its returned `nextCursor` via
`--cursor` for the next page. It does not support `--page-all`. `docs comments
replies` returns up to 25 items per page and a `nextCursor`; pass that cursor
manually or use `--page-all` to fetch all pages (bounded by `--page-limit`,
default 10). Stop when `nextCursor` is null. `docs comments get` returns both
the requested comment and its authoritative root; for a reply, use
`root.anchor` as the thread's anchor.

Anchors are opaque base64-encoded Yjs positions produced by the editor — the
backend never parses base64 anchors. A bot with no live editor selection can
still start an anchored thread with `--anchorText`: the backend locates that text
in the stored document and computes the anchor. When the text occurs more than
once the request fails loudly with `422 ambiguous_anchor` (never a silent guess)
— narrow it with `--blockPath` and/or `--occurrence`. Text that is not found
returns `422 anchor_text_not_found`.

### Commenting on a spreadsheet cell (doc_type 'sheet')

A `sheet` has no rich-text body, so `--anchorText` does NOT work on it (returns
`409 unsupported_doc_type` — anchor-text resolution needs a ProseMirror fragment).
Instead a sheet comment anchors to a **cell**: pass the base64 of the cell key
`${sheetId}!${row}:${col}` as BOTH `--anchorStart` and `--anchorEnd`, and put the
human-readable A1 label in `--anchorText` (display only, not resolved). `row`/`col`
are 0-based; `sheetId` is the logical sheet id (`default` for a single-sheet doc).

```bash
# Comment on cell A1 (row 0, col 0) of the default sheet.
CELL=$(printf 'default!0:0' | base64)          # -> ZGVmYXVsdCEwOjA=
octo-cli docs comments add <sheetDocId> \
  --body "This total looks off" \
  --anchorStart "$CELL" --anchorEnd "$CELL" --anchorText "A1"
```

List / reply / resolve / delete work identically to document comments; the badge
a reader sees on the cell is driven by this anchor. Schema: `octo-cli schema docs.comments.add`.

---

## Versions

Snapshot / preview / restore, for any doc kind (document / sheet / board).

```bash
octo-cli docs versions list    <docId> [--kind manual|auto|all] [--cursor <id>] [--limit <n>]
octo-cli docs versions create  <docId> [--label "before restructure"]   # writer
octo-cli docs versions state   <docId> <versionId>   # read-only decoded preview (reader)
octo-cli docs versions rename  <docId> <versionId> --label "v2"          # writer
octo-cli docs versions delete  <docId> <versionId>                       # admin
octo-cli docs versions restore <docId> <versionId>                       # admin
```

> **`<versionId>` is the version's `docVersionSeq`** — the integer returned by
> `docs versions create` and shown as `docVersionSeq` in `docs versions list`.
> There is no separate id field; pass that integer.

`versions state` reads *historical* content: a past snapshot decoded by the doc's
kind — a document/sheet as `{kind:"document", doc, sheetCells, sheetDims, ...}`, a
board as `{kind:"board", scene, ...}`. It is a preview, not the live document, and
is not writable. To read the **live** content, use `docs content get` (`doc.md`),
`docs sheet get` (`sheet.md`), or `docs scene get` (`board.md`).
For a text document, every returned sheet map (`sheetCells`, `sheetDims`,
`sheetList`, `sheetFreeze`, `sheetFilters`, and `sheetDataValidations`) is an
empty `{}`. For a sheet snapshot, `sheetList` carries each tab's optional
`rowCount` / `columnCount`; missing counts identify a legacy 1000-by-100 tab.

`restore` is non-destructive and records a safety snapshot first, so it is itself
undoable. For a sheet, restore rolls back the full grid — cells, column-width /
row-height dims, floating images, hyperlinks, merges, sheet tabs, freeze panes,
shared filters, and data-validation rules — to the target version.
Schema: `octo-cli schema docs.versions.restore`.

---

## Members & sharing

```bash
octo-cli docs members list   <docId>                             # reader or higher; items include principalSpaceId
octo-cli docs members set    <docId> --uid <uid> --role writer   # authenticated Bot Space; role: reader|commenter|writer|admin
octo-cli docs members set    <docId> --uid <uid> --role writer --principal-space-id <spaceId>
octo-cli docs members remove <docId> <uid> --principal-space-id <spaceId> # required; owner cannot be removed

# Grant-only forward access (never downgrades). Only reader|commenter|writer are grantable.
octo-cli docs forward-grant  <docId> --uid <uid> --role reader

# Space-level share scope — read/set who in the space can reach the doc.
octo-cli docs share get <docId>  # read the current settings and permissionEpoch first
# Each alternative below needs a fresh epoch from that read, not a fixed/example value.
octo-cli docs share set <docId> --scope restricted --permissionEpoch <epoch>
octo-cli docs share set <docId> --scope anyone_in_space --role read --permissionEpoch <epoch>
octo-cli docs share set <docId> --scope anyone_in_space --role edit --permissionEpoch <epoch>
```

`docs members set` is a Space-qualified Bot mutation. Omit
`--principal-space-id` to use the authenticated Bot Space, or pass that same
Space explicitly; either form can add a member or update an existing role. A
foreign Space is never queried through the directory and can only update an
existing exact `(docId, uid, principalSpaceId)` row; if that row is absent, the
backend returns `404`. A uid can have distinct member rows in multiple Spaces,
so `docs members remove` always requires `--principal-space-id` and deletes the
exact qualified row. Schemas:
`octo-cli schema docs.members.set` and `octo-cli schema docs.members.remove`.

`docs share set` changes the space-level share scope. Two scopes: `restricted`
(only the owner and explicit members reach the doc — the default) and
`anyone_in_space` (every member of the doc's own space is granted the share
role). The `--role` (`read` | `edit`) is **required** with `--scope
anyone_in_space` and is **ignored** with `--scope restricted` (the backend
normalizes it to `read`), so omit `--role` when restricting. Sharing only ever
*raises* access — an owner or member is never downgraded by a share setting.
Error codes: `400 invalid_scope` (unknown scope), `400 invalid_role`
(anyone_in_space with a missing/invalid role), `403` (caller not admin/owner),
`404` (missing or cross-space doc), `409` (archived doc). Schema:
`octo-cli schema docs.share.set`.

Every share update requires `--permissionEpoch` from a fresh `docs share get`.
This is the permission version, not the document/PPT content revision. A missing
or invalid epoch fails local validation. On `409 share_settings_conflict`,
re-read the current sharing settings and re-evaluate the change before submitting;
do not automatically overwrite a concurrent administrator's decision. The CLI
does not fetch an epoch or retry a permission conflict on the caller's behalf.

---

## Attachments

The attachment-presign flow below is **presign-only**: the CLI never streams the
binary through these commands. PPT also has a direct authenticated binary-media
endpoint used by a runtime HTTP client; see `ppt.md` for that distinct flow. Uploading
is a two-step flow — presign to register the row and get a signed PUT URL, then PUT
the bytes yourself directly to object storage.
The size must be a positive integer (at least 1 byte). The backend applies its
configured cap by MIME tier: `image/` types use the image cap; other types use
the file cap.

```bash
# Step 1: register + get a presigned PUT target.
octo-cli docs attachments presign <docId> \
  --fileName report.pdf --mime application/pdf --sizeBytes 20481

# The response contains: attachId, uploadUrl, headers{...}, expiresInSec, ...
# Step 2: upload the bytes yourself (NOT through octo-cli — the URL is a
# pre-authorized object-store URL that must not carry the bot Authorization header).
curl -X PUT --upload-file report.pdf \
  -H "Content-Type: application/pdf" \
  "<uploadUrl>"
# Add every header returned under "headers" to the PUT exactly as given.

# Read back a single attachment's signed download URL, or resolve many at once.
octo-cli docs attachments get     <docId> <attachId>
octo-cli docs attachments resolve <docId> --attachIds a1 --attachIds a2
```

> There is no `docs attachments upload` command in this version — the raw PUT
> cannot go through `octo-cli api` either, because that path always prepends
> `OCTO_API_BASE_URL` and attaches the bot bearer token, both wrong for a
> presigned object-store URL. Do the PUT with `curl` (or any HTTP client).

Once uploaded, reference the `attachId` from a document body's image node (see
`doc.md`) or a whiteboard file ref (see `board.md`). NOTE: a spreadsheet's floating
images do NOT use this attachment flow — they inline the base64 bytes in the
drawing's `source` field (see `sheet.md`). Schema: `octo-cli schema docs.attachments.presign`.

### External image URLs (including SVG)

The image-node instructions below are for rich-text documents. For PPT images,
audio and video, use the PPT-specific shared-ingest instructions in `ppt.md`:
the same endpoint returns native media references on a compatible backend.

Never persist an arbitrary external URL as an image node's only `src`. Current
Octo clients render images only from trusted storage hosts, so a node such as
`{"type":"image","attrs":{"src":"https://third-party.example/image.svg"}}`
can be stored but renders as **Image unavailable**.

Re-host a public HTTP(S) image under the target document first. The ingest
endpoint is not yet a generated `docs attachments` subcommand, so call it
through the generic API passthrough:

```bash
octo-cli api POST /v1/bot/docs/<docId>/attachments/ingest \
  --no-retry --data '{"urls":["https://source.example/diagram.svg"]}'
```

Ingestion is not idempotent across requests: replaying a POST can create duplicate
attachments. Keep successful receipts, retry only failed entries and reconcile an
uncertain timeout before retrying; do not automatically repeat the whole batch.

Read the new document-scoped `attachId` from `data.mappings`; treat an entry in
`data.notIngested` as a failed image import and keep it as a normal hyperlink or
text instead of writing a broken image node. The backend fetches the source with
SSRF protections, validates that the bytes are an allowed image, and stores the
successful result in Octo object storage.

After either upload or ingest succeeds, write the image node using its durable
`attachId`. Omit `src` (or set it to `null`): the client resolves a fresh signed
display URL from the attachment. Also provide a positive pixel `width`; current
clients can collapse an agent-created image with `width: null` to `0x0`. Use the
known display width when available, otherwise `300` is a safe compatibility
default:

```json
{
  "type": "image",
  "attrs": {
    "attachId": "att_xxx",
    "width": 300,
    "alt": "Diagram"
  }
}
```

The `attachId` must belong to the same target document; a foreign or unknown
attachment is rejected with `422 attachment_not_found`.
