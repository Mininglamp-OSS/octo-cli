package mcp

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"

	"github.com/spf13/cobra"
	"github.com/spf13/pflag"

	"github.com/Mininglamp-OSS/octo-cli/internal/cmdutil"
	"github.com/Mininglamp-OSS/octo-cli/internal/foldkey"
	"github.com/Mininglamp-OSS/octo-cli/internal/output"
	"github.com/Mininglamp-OSS/octo-cli/internal/registry"
)

// RootBuilder builds a fresh root cobra command bound to f. It is injected from
// package cmd (cmd.NewRootCmd) so this package does not import cmd (which would
// be a cycle). A FRESH root per call_op is required: cobra retains parsed flag
// state on a command, so reusing one root would leak a previous call's flags
// into the next.
type RootBuilder func(f *cmdutil.Factory) *cobra.Command

// execPolicy carries the connection's capability posture into argument
// translation: whether this is the HTTP transport (untrusted client) and, if
// so, the operator-confined upload root that a multipart file_path must stay
// within. describeHint is the facade-aware recovery hint used when translation
// fails, so a --facade two caller is pointed at get_skill, not describe_op.
type execPolicy struct {
	httpMode         bool
	uploadRoot       string // OCTO_MCP_UPLOAD_ROOT; "" => local upload disabled unless allowLocalUpload
	describeHint     string
	dryRun           bool
	allowLocalUpload bool                                       // operator --allow-local-upload: unconfined pass-through, stdio only
	typedSlices      bool                                       // execution sets query slices directly, bypassing CLI CSV parsing
	uploadOpener     func(string, execPolicy) (*os.File, error) // nil uses descriptor-confined openUpload
}

// maxInlineBinaryBytes bounds a binary response body returned inline by an MCP
// call (base64 or UTF-8 text). Larger bodies are described by size and sha256
// with inline:false; nothing is ever written to the server's filesystem.
const maxInlineBinaryBytes = 4 << 20

// reservedFlagNames are the engine/root flag names a translated argument must
// never be able to synthesize (identity/scope/output controls + engine flags).
// A model-supplied key that maps to one of these is refused before cobra sees
// it, so call_op cannot smuggle --profile/--bot-id/--space/--format/--verbose
// (or --data/--file/…) through an undeclared multipart or spec parameter.
var reservedFlagNames = map[string]bool{
	"format": true, "jq": true, "dry-run": true, "verbose": true,
	"timeout": true, "no-retry": true, "space": true, "bot-id": true, "profile": true,
	"data": true, "file": true, "page-all": true, "page-limit": true, "output": true, "o": true,
	// cobra auto-registers help on every command; a spec param named help/h would
	// otherwise print usage instead of executing.
	"help": true, "h": true,
}

// callGlobals is the operator GlobalOptions carried into a per-call factory. It
// is applied AFTER build() (which resets the fresh root's persistent flags to
// their defaults), so operator routing/limit/safety intent is not silently
// dropped.
//
// The propagate/reset split is deliberate and asserted by
// TestCallGlobals_EveryFieldClassified so a newly added GlobalOptions field
// fails loudly instead of vanishing:
//   - propagate (operator legitimately controls per call): BotID, Profile,
//     Timeout, NoRetry, DryRun — plus Space, which the trusted context supplies.
//     DryRun in particular is a safety switch, not an output knob: an operator
//     who starts `mcp serve --dry-run` gets a rehearsal server where every call
//     prints its request and performs no backend mutation, honoring the flag's
//     documented "print request without executing" contract.
//   - reset (must never be inherited into a per-call run): Format (pinned to
//     json — the tool result must stay an envelope), Verbose, JQ, PageAll,
//     PageMax (output/pagination knobs the model does not control).
func applyCallGlobals(g *cmdutil.GlobalOptions, base cmdutil.GlobalOptions, forcedSpace string) { //nolint:gocritic // copy operator globals so calls cannot mutate serve-time settings
	// Propagate operator-set routing/limit/safety knobs.
	g.BotID = base.BotID
	g.Profile = base.Profile
	g.Timeout = base.Timeout
	g.NoRetry = base.NoRetry
	g.DryRun = base.DryRun
	// Trusted space wins over anything build() or the base carried.
	g.Space = forcedSpace
	// Reset: never inherit these into a per-call execution.
	g.Format = output.FormatJSON
	g.Verbose = false
	g.JQ = ""
	g.PageAll = false
	g.PageMax = 0
}

// executeOperation runs one operation through the generated cobra tree
// in-process, reusing identity routing, request assembly, pre-flight
// validation, transport, secret masking, and envelope emission unchanged. It
// writes into f's buffers and returns the JSON envelope plus whether the
// operation succeeded. Pre-flight translation problems and cobra parse errors
// are rendered as an error envelope so the caller always gets one.
//
// globalFlags are extra persistent/global flags (e.g. "--dry-run") spliced in
// before the "--" positional separator. The three-tool call_op passes none, so
// its argv is byte-for-byte what it was; the two-tool execute facade uses this
// to honour dry-run without a second request-assembly path.
func executeOperation(ctx context.Context, build RootBuilder, f *cmdutil.Factory, detail *registry.OperationDetail, arguments map[string]any, pol execPolicy, outBuf, errBuf *bytes.Buffer, globalFlags ...string) (envelope []byte, ok bool, exitErr *output.ExitError) {
	if err := guardOperationArguments(ctx, detail.ID, arguments); err != nil {
		ee := output.ErrValidation(err.Error(), "")
		return synthErrorEnvelope(ee), false, ee
	}
	outBuf.Reset()
	errBuf.Reset()
	pol.dryRun = effectiveDryRun(pol.dryRun || f.Globals.DryRun, globalFlags)
	f.Globals.DryRun = pol.dryRun
	// Both facades must stop before path resolution can touch the filesystem.
	if pol.dryRun && (detail.Multipart || detail.RawBody) {
		return planUploadDryRun(ctx, f, detail, arguments, pol)
	}
	pol.typedSlices = true

	argv, terr := buildArgv(ctx, detail, arguments, pol)
	if terr != nil {
		hint := pol.describeHint
		if hint == "" {
			hint = "call describe_op to see the operation's declared arguments"
		}
		ee := argvError(terr, hint)
		return synthErrorEnvelope(ee), false, ee
	}
	argv = spliceGlobalFlags(argv, globalFlags)
	if detail.Multipart || detail.RawBody {
		if value, ok := arguments["file_path"]; ok && value != nil && fmt.Sprint(value) != "" {
			file, err := pol.openFile(fmt.Sprint(value))
			if err != nil {
				ee := output.ErrValidation(err.Error(), "check the configured upload root and file path")
				return synthErrorEnvelope(ee), false, ee
			}
			f.MultipartFile = file
			defer func() {
				_ = file.Close() //nolint:errcheck // read-only descriptor cleanup
				f.MultipartFile = nil
			}()
		}
	}

	// MCP callers have no filesystem destination for a binary response (the
	// reserved --output flag cannot be synthesized), so a bounded copy of the
	// body is returned inside the envelope instead of only its size and type.
	f.InlineBinaryLimit = maxInlineBinaryBytes
	// The drive share composites take a different argument shape than the
	// spec; MCP executes the generated leaves its published schema describes.
	f.GeneratedDriveShareLeaves = true

	// Snapshot the operator globals makeFactory set on f BEFORE build(): root's
	// persistent-flag registration resets *f.Globals to empty defaults, so the
	// operator's routing/limit intent (and the trusted space) must be re-applied
	// afterward or it is silently dropped.
	base := *f.Globals
	forcedSpace := base.Space

	root := build(f)
	applyCallGlobals(f.Globals, base, forcedSpace)
	root.SetArgs(argv)
	root.SetOut(outBuf)
	root.SetErr(errBuf)
	root.SilenceUsage = true
	root.SilenceErrors = true
	if err := replaceQuerySlices(root, detail, arguments); err != nil {
		ee := output.ErrValidation(err.Error(), pol.describeHint)
		return synthErrorEnvelope(ee), false, ee
	}

	execErr := root.ExecuteContext(ctx)
	env, runOK := readEnvelope(outBuf, errBuf, execErr)
	// execErr carries the *ExitError even when RunE also wrote the envelope to
	// errBuf (emitOnce returns the same error it emitted), so machine-readable
	// outcome classification (auth vs ambiguous vs plain failure) is available
	// to the two-tool execute facade without re-parsing the rendered JSON.
	return env, runOK, output.AsExitError(execErr)
}

func effectiveDryRun(current bool, globalFlags []string) bool {
	if current {
		return true
	}
	for _, flag := range globalFlags {
		if flag == "--dry-run" {
			return true
		}
	}
	return false
}

func (pol execPolicy) openFile(path string) (*os.File, error) {
	if pol.uploadOpener != nil {
		return pol.uploadOpener(path, pol)
	}
	return openUpload(path, pol)
}

// readEnvelope picks the envelope the run produced. A successful RunE writes a
// full envelope to outBuf; an error RunE writes an error envelope to errBuf; a
// cobra parse / auth gate failure returns via execErr with both buffers empty.
//
// outBuf is preferred whenever it parses as an envelope, so a benign diagnostic
// on stderr (e.g. a client warning line) can never mask a real success — the
// envelope contract stays intact even if something writes to errBuf alongside a
// good result.
func readEnvelope(outBuf, errBuf *bytes.Buffer, execErr error) ([]byte, bool) {
	if outBuf.Len() > 0 && looksLikeEnvelope(outBuf.Bytes()) {
		b := append([]byte(nil), outBuf.Bytes()...)
		return b, envelopeOK(b)
	}
	if errBuf.Len() > 0 && looksLikeEnvelope(errBuf.Bytes()) {
		return append([]byte(nil), errBuf.Bytes()...), false
	}
	if errBuf.Len() > 0 {
		// Non-envelope stderr content with no usable envelope: wrap it.
		return synthErrorEnvelope(output.ErrWithHint("internal", "UNEXPECTED_OUTPUT", strings.TrimSpace(errBuf.String()), "")), false
	}
	if execErr != nil {
		return synthErrorEnvelope(cmdutil.WrapCLIError(execErr)), false
	}
	return synthErrorEnvelope(output.ErrWithHint("internal", "NO_OUTPUT", "operation produced no output", "")), false
}

// looksLikeEnvelope reports whether b decodes to a JSON object carrying an "ok"
// field — the shared shape of both success and error envelopes.
func looksLikeEnvelope(b []byte) bool {
	var env struct {
		OK *bool `json:"ok"`
	}
	return json.Unmarshal(b, &env) == nil && env.OK != nil
}

// envelopeOK reports whether an envelope's top-level "ok" is true.
func envelopeOK(b []byte) bool {
	var env struct {
		OK bool `json:"ok"`
	}
	return json.Unmarshal(b, &env) == nil && env.OK
}

// synthErrorEnvelope renders an ExitError as a standalone error envelope, for
// failures that occur before (or instead of) the engine emitting one.
func synthErrorEnvelope(err error) []byte {
	var buf bytes.Buffer
	_ = output.WriteError(&buf, cmdutil.WrapCLIError(err)) //nolint:errcheck // in-memory buffer write cannot fail
	return buf.Bytes()
}

// toolSafetyArgumentNames are the execute tool's own switches, keyed by
// safetyNameKey. Inside an operation's arguments they are never operation
// input; an undeclared dry_run would otherwise be forwarded as body data while
// the call runs live.
var toolSafetyArgumentNames = map[string]bool{
	safetyNameKey("dry_run"):            true,
	safetyNameKey("schema_fingerprint"): true,
}

// safetyNameSeparators are dropped when comparing a name with the tool
// switches, so dry-run, dryRun and DRY_RUN all match dry_run.
var safetyNameSeparators = strings.NewReplacer("_", "", "-", "")

// safetyNameKey folds a name for comparison with the tool switches. It uses the
// same Unicode simple folding as the declared-name index (foldkey.Key, which
// agrees with strings.EqualFold) rather than ASCII lowercasing, so spellings
// such as "ſchema_fingerprint" (U+017F long s) that a case-insensitive JSON
// binder treats as schema_fingerprint are recognised too. The cost is linear
// in the length of the name.
func safetyNameKey(name string) string {
	return safetyNameSeparators.Replace(foldkey.Key(name))
}

// maxArgumentNames bounds how many top-level argument names one call may carry.
// The largest operation declares a few dozen parameters and body fields, so
// this leaves ample room for legitimate extra fields while keeping the name
// checks below, which run before any credential is resolved, to a fixed
// amount of work per request.
const maxArgumentNames = 1024

// argumentCheckInterval is how many argument names are examined between
// context checks, so a cancelled or timed-out request stops validating.
const argumentCheckInterval = 64

// errArgumentsCancelled marks a call whose context ended during argument
// validation. Nothing was sent, so it is reported as a local refusal rather
// than as an execution with an unknown outcome.
type errArgumentsCancelled struct{ err error }

func (e errArgumentsCancelled) Error() string {
	return "request cancelled before argument validation completed: " + e.err.Error()
}

func (e errArgumentsCancelled) Unwrap() error { return e.err }

// argvError renders a buildArgv failure. A context that ended during argument
// validation is REQUEST_CANCELLED; every other failure is a VALIDATION_ERROR.
// Neither sent anything.
func argvError(err error, hint string) *output.ExitError {
	var cancelled errArgumentsCancelled
	if errors.As(err, &cancelled) {
		return output.ErrWithHint("validation", "REQUEST_CANCELLED", err.Error(), "nothing was sent; retry with a longer deadline")
	}
	return output.ErrValidation(err.Error(), hint)
}

// checkArgumentNames refuses argument names that could change what the call
// does without looking like it:
//   - a misplaced tool switch (dry_run, schema_fingerprint, or a spelling of
//     them with other case or separators) that the operation does not declare;
//   - a name that is not a declared parameter or body field but equals one
//     under Unicode case folding (for example "ſpace_id" for "space_id"), or two
//     names that fold together. A Go backend binds JSON keys case-insensitively
//     with this folding and the last match wins, so such a key could override
//     a declared or connection-forced value that is also in the body.
//
// It runs before credential resolution, so its cost is bounded: at most
// maxArgumentNames names are accepted, each is folded once into an index
// (linear in the total name length rather than pairwise), and ctx is checked
// before the work starts and periodically while it runs.
func checkArgumentNames(ctx context.Context, args map[string]any, pathSet map[string]bool, query, header map[string]*registry.ParamInfo, body map[string]registry.SchemaInfo) error {
	if err := ctx.Err(); err != nil {
		return errArgumentsCancelled{err}
	}
	if len(args) > maxArgumentNames {
		return fmt.Errorf("too many arguments: %d names exceed the limit of %d", len(args), maxArgumentNames)
	}
	declared := declaredArgumentNames(pathSet, query, header, body)
	// Index declared names by fold key. Distinct declared names that fold
	// together keep the smallest, so the reported spelling is deterministic.
	declaredByFold := make(map[string]string, len(declared))
	for n := range declared {
		fk := foldkey.Key(n)
		if prev, ok := declaredByFold[fk]; !ok || n < prev {
			declaredByFold[fk] = n
		}
	}
	keys := sortedKeys(args)
	seen := make(map[string]string, len(keys))
	for i, k := range keys {
		if i%argumentCheckInterval == 0 {
			if err := ctx.Err(); err != nil {
				return errArgumentsCancelled{err}
			}
		}
		fk := foldkey.Key(k)
		if declared[k] {
			seen[fk] = k
			continue
		}
		if toolSafetyArgumentNames[safetyNameKey(k)] {
			return fmt.Errorf("argument %q is a tool option, not an operation argument; execute takes dry_run and schema_fingerprint next to operation_id", truncateRunes(k, 200))
		}
		if n, ok := declaredByFold[fk]; ok {
			return fmt.Errorf("argument %q is not the declared spelling of %q", truncateRunes(k, 200), n)
		}
		if other, ok := seen[fk]; ok {
			return fmt.Errorf("arguments %q and %q differ only by case folding", truncateRunes(other, 200), truncateRunes(k, 200))
		}
		seen[fk] = k
	}
	return nil
}

func declaredArgumentNames(pathSet map[string]bool, query, header map[string]*registry.ParamInfo, body map[string]registry.SchemaInfo) map[string]bool {
	declared := map[string]bool{"page_all": true, "file_path": true}
	for n := range pathSet {
		declared[n] = true
	}
	for n := range query {
		declared[n] = true
	}
	for n := range header {
		declared[n] = true
	}
	for n := range body {
		declared[n] = true
	}
	return declared
}

// buildArgv translates an MCP call_op arguments object into CLI argv for the
// operation's generated leaf command. Path parameters become positionals after
// a "--" separator (so a base64url id starting with "-" is never parsed as a
// flag); a query parameter that declares x-octo-positional follows them, in
// spec order, exactly where the engine's leaf command reads its operand (so a
// search term starting with "-" stays data too); every other query and header
// parameter becomes its spec-derived flag; every remaining declared/extra field
// is passed as the JSON --data body so run.go's merged-body validator judges it
// at every depth (no second validator here).
//
// Two capability guards run here, before cobra parsing:
//   - A synthesized flag name may never be a reserved engine/root flag: a
//     model cannot inject --profile/--bot-id/--space/--format/--verbose/etc.
//   - For a multipart operation, only fields the schema declares (plus the file
//     binding) are accepted; an undeclared key is rejected rather than turned
//     into an arbitrary --key flag.
//   - A multipart file_path is confined per policy: over HTTP it is denied
//     unless an operator upload root is configured and the resolved path
//     (symlinks included) stays within it.
//
// A query/header argument whose value is JSON null is dropped (null means
// "omitted", not "send an empty value"), so a null scope parameter cannot empty
// a required filter on the wire.
func buildArgv(ctx context.Context, d *registry.OperationDetail, args map[string]any, pol execPolicy) ([]string, error) { //nolint:gocyclo // spec-driven argument assembly handles distinct parameter locations and upload policy
	pathNames := extractPathParams(d.Path)
	pathSet := make(map[string]bool, len(pathNames))
	for _, n := range pathNames {
		pathSet[n] = true
	}

	queryByName := map[string]*registry.ParamInfo{}
	headerByName := map[string]*registry.ParamInfo{}
	for i := range d.Parameters {
		p := &d.Parameters[i]
		switch p.In {
		case "query":
			queryByName[p.Name] = p
		case "header":
			headerByName[p.Name] = p
		}
	}
	declaredBody := map[string]registry.SchemaInfo{}
	if d.RequestBody != nil {
		for name, prop := range d.RequestBody.Properties { //nolint:gocritic // schema properties are read-only values
			declaredBody[name] = prop
		}
	}

	if err := checkArgumentNames(ctx, args, pathSet, queryByName, headerByName, declaredBody); err != nil {
		return nil, err
	}

	var flags []string
	body := map[string]any{}
	var pageAll bool
	var filePath string
	var unexpected []string

	for _, k := range sortedKeys(args) {
		v := args[k]
		switch {
		case k == "page_all":
			if b, ok := v.(bool); ok {
				pageAll = b
			}
		case k == "file_path" && (d.Multipart || d.RawBody):
			if v != nil {
				filePath = fmt.Sprint(v)
			}
		case pathSet[k]:
			// consumed as a positional below
		case queryByName[k] != nil && queryByName[k].PositionalName != "":
			// consumed as a positional below: the engine registers no flag
			// for it, only the <operand> after the path values
		case queryByName[k] != nil:
			if v == nil {
				continue // null query arg => omitted, not an empty scope
			}
			fn := flagName(queryByName[k])
			if reservedFlagNames[fn] {
				return nil, fmt.Errorf("argument %q maps to reserved flag --%s and cannot be set", k, fn)
			}
			if _, array := v.([]any); pol.typedSlices && array && queryByName[k].Type == "array" {
				continue // set with SliceValue.Replace after building the leaf
			}
			vs, err := flagArgs(fn, v)
			if err != nil {
				return nil, err
			}
			flags = append(flags, vs...)
		case headerByName[k] != nil:
			if v == nil {
				continue // null header arg => omitted
			}
			fn := flagName(headerByName[k])
			if reservedFlagNames[fn] {
				return nil, fmt.Errorf("argument %q maps to reserved flag --%s and cannot be set", k, fn)
			}
			vs, err := flagArgs(fn, v)
			if err != nil {
				return nil, err
			}
			flags = append(flags, vs...)
		case d.RawBody:
			// A raw-body upload's request body is the file itself: there is no
			// JSON body and no form field, so any other key is undeclared.
			unexpected = append(unexpected, k)
		case d.Multipart:
			// Multipart ops take no --data; a declared body field rides as a
			// form-text flag. An UNDECLARED key is refused, so it can never
			// synthesize an arbitrary or reserved flag.
			prop, ok := declaredBody[k]
			if !ok {
				unexpected = append(unexpected, k)
				continue
			}
			fn := strings.ReplaceAll(k, "_", "-")
			if reservedFlagNames[fn] {
				return nil, fmt.Errorf("argument %q maps to reserved flag --%s and cannot be set", k, fn)
			}
			vs, err := flagArgs(fn, coerceToSchema(prop, v))
			if err != nil {
				return nil, err
			}
			flags = append(flags, vs...)
		case d.RequestBody != nil:
			// Coerce to the declared property type so a forced/string value (e.g.
			// a header-sourced channel_type "1") lands on the wire as the integer
			// the schema declares, matching what a typed CLI flag would send.
			if prop, ok := declaredBody[k]; ok {
				body[k] = coerceToSchema(prop, v)
			} else {
				body[k] = v
			}
		default:
			unexpected = append(unexpected, k)
		}
	}

	if len(unexpected) > 0 {
		sort.Strings(unexpected)
		msg := fmt.Sprintf("unexpected argument(s) for %s: %s", d.ID, strings.Join(unexpected, ", "))
		// A positional query parameter shows its CLI operand label next to its
		// wire name, so name the argument a caller most likely meant. The
		// label itself is still refused: it is not an argument.
		for _, k := range unexpected {
			for i := range d.Parameters {
				if p := &d.Parameters[i]; p.In == "query" && p.PositionalName == k {
					msg += fmt.Sprintf(" (%q is the CLI operand label of query argument %q; pass it as %q)", k, p.Name, p.Name)
				}
			}
		}
		return nil, errors.New(msg)
	}

	if len(body) > 0 {
		raw, err := json.Marshal(body)
		if err != nil {
			return nil, fmt.Errorf("encode request body: %w", err)
		}
		flags = append(flags, "--data="+string(raw))
	}
	if pageAll && d.Pagination != nil {
		flags = append(flags, "--page-all")
	}
	if filePath != "" {
		resolved, err := resolveUploadPath(filePath, pol)
		if err != nil {
			return nil, err
		}
		flags = append(flags, "--file="+resolved)
	}

	positionals := make([]string, 0, len(pathNames))
	for _, n := range pathNames {
		pv, ok := args[n]
		if !ok {
			return nil, fmt.Errorf("missing required path argument %q for %s", n, d.ID)
		}
		s, err := scalarString(pv)
		if err != nil {
			return nil, fmt.Errorf("path argument %q: %w", n, err)
		}
		positionals = append(positionals, s)
	}
	// Positional query operands, in declaration order: the same order the
	// engine registers them (cmd/service registerQueryFlags) and reads them
	// back from the tail of its args. The engine's leaf command requires every
	// one of them (cobra.ExactArgs), so an absent or null value is reported
	// here by its wire name instead of as an operand-count error.
	for i := range d.Parameters {
		p := &d.Parameters[i]
		if p.In != "query" || p.PositionalName == "" {
			continue
		}
		pv, ok := args[p.Name]
		if !ok || pv == nil {
			return nil, fmt.Errorf("missing required query argument %q for %s", p.Name, d.ID)
		}
		s, err := scalarString(pv)
		if err != nil {
			return nil, fmt.Errorf("query argument %q: %w", p.Name, err)
		}
		positionals = append(positionals, s)
	}

	argv := append([]string{}, commandWords(d)...)
	argv = append(argv, flags...)
	if len(positionals) > 0 {
		argv = append(argv, "--")
		argv = append(argv, positionals...)
	}
	return argv, nil
}

// replaceQuerySlices preserves already-decoded JSON elements, including CRLF
// and empty strings. Only MCP uses this bridge; CLI flags retain CSV syntax.
func replaceQuerySlices(root *cobra.Command, d *registry.OperationDetail, args map[string]any) error {
	leaf, _, err := root.Find(commandWords(d))
	if err != nil {
		return err
	}
	for i := range d.Parameters {
		p := &d.Parameters[i]
		items, supplied := args[p.Name].([]any)
		if !supplied || p.In != "query" || p.Type != "array" || p.PositionalName != "" {
			continue
		}
		flag := leaf.Flags().Lookup(flagName(p))
		if flag == nil {
			return fmt.Errorf("array parameter %q has no declared flag", p.Name)
		}
		slice, ok := flag.Value.(pflag.SliceValue)
		if !ok {
			return fmt.Errorf("array parameter %q has no slice flag", p.Name)
		}
		values := make([]string, len(items))
		for j, item := range items {
			values[j], err = scalarString(item)
			if err != nil {
				return fmt.Errorf("array parameter %q: %w", p.Name, err)
			}
		}
		if err := slice.Replace(values); err != nil {
			return fmt.Errorf("array parameter %q: %w", p.Name, err)
		}
		flag.Changed = true
	}
	return nil
}

// commandWords maps an operationId to its CLI command path words, matching the
// engine's own registration rule (cmd/service/service.go attachOperation):
// the service name, then every operationId segment after the first when that
// first segment equals the service (docs.create -> docs create), or every
// segment when it differs (mcp.probe under marketplace -> marketplace mcp
// probe). Underscores become dashes, as the engine does.
func commandWords(d *registry.OperationDetail) []string {
	segs := strings.Split(d.ID, ".")
	start := 1
	if len(segs) == 0 || segs[0] != d.Service {
		start = 0
	}
	words := []string{d.Service}
	for _, s := range segs[start:] {
		words = append(words, strings.ReplaceAll(s, "_", "-"))
	}
	return words
}

// flagName derives a parameter's CLI flag name the same way flags.go does: an
// explicit x-octo-flag override, else the wire name with underscores dashed.
func flagName(p *registry.ParamInfo) string {
	if p.FlagName != "" {
		return p.FlagName
	}
	return strings.ReplaceAll(p.Name, "_", "-")
}

// flagArgs renders one argument value as "--name=value" tokens. A string slice
// repeats the flag; scalars are stringified losslessly (json.Number keeps its
// exact decimal text so a uint64 id is never rounded).
func flagArgs(name string, v any) ([]string, error) {
	if arr, ok := v.([]any); ok {
		out := make([]string, 0, len(arr))
		for _, e := range arr {
			s, err := scalarString(e)
			if err != nil {
				return nil, fmt.Errorf("argument --%s: %w", name, err)
			}
			out = append(out, "--"+name+"="+s)
		}
		return out, nil
	}
	s, err := scalarString(v)
	if err != nil {
		return nil, fmt.Errorf("argument --%s: %w", name, err)
	}
	return []string{"--" + name + "=" + s}, nil
}

// coerceToSchema converts a string value to the primitive JSON type the schema
// declares (integer/number/boolean), so a trusted-context or header-sourced
// value such as channel_type "1" reaches the wire as the integer 1 the backend
// expects — matching what a typed CLI flag would send. Anything that does not
// cleanly convert is left unchanged for the normal validator to judge.
func coerceToSchema(prop registry.SchemaInfo, v any) any { //nolint:gocritic // read-only schema snapshot
	s, ok := v.(string)
	if !ok {
		return v
	}
	switch prop.Type {
	case "integer":
		if n, err := strconv.ParseInt(s, 10, 64); err == nil {
			return json.Number(strconv.FormatInt(n, 10))
		}
	case "number":
		if _, err := strconv.ParseFloat(s, 64); err == nil {
			return json.Number(s)
		}
	case "boolean":
		if b, err := strconv.ParseBool(s); err == nil {
			return b
		}
	}
	return v
}

// scalarString stringifies a JSON scalar for a flag / positional value.
func scalarString(v any) (string, error) {
	switch t := v.(type) {
	case string:
		return t, nil
	case bool:
		return strconv.FormatBool(t), nil
	case json.Number:
		return t.String(), nil
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64), nil
	case nil:
		return "", nil
	default:
		return "", fmt.Errorf("unsupported value type %T", v)
	}
}

// extractPathParams returns {placeholder} names in path order (mirrors the
// engine helper of the same name, which is unexported).
func extractPathParams(path string) []string {
	var out []string
	for {
		start := strings.IndexByte(path, '{')
		if start < 0 {
			return out
		}
		end := strings.IndexByte(path[start:], '}')
		if end < 0 {
			return out
		}
		end += start
		out = append(out, path[start+1:end])
		path = path[end+1:]
	}
}

// disabledOpError reports a call to an operation on a withheld service. The
// discoveryTool is the facade's discovery entrypoint (search_ops or get_skill).
func disabledOpError(operationID, discoveryTool string) error {
	return output.ErrValidation(
		fmt.Sprintf("operation %q belongs to a disabled service and is not callable", operationID),
		fmt.Sprintf("this service is withheld; it is not exposed by %s", discoveryTool))
}

// divergentOpError reports an operation whose generated schema does not match
// its callable shape, pointing at the CLI form that does work.
func divergentOpError(operationID, cli string) error {
	return output.ErrValidation(
		fmt.Sprintf("operation %q is not available over MCP: its generated schema does not describe the callable request shape", operationID),
		fmt.Sprintf("use the CLI form instead: %s", cli))
}

func sortedKeys(m map[string]any) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func spliceGlobalFlags(argv, flags []string) []string {
	sep := len(argv)
	for i, a := range argv {
		if a == "--" {
			sep = i
			break
		}
	}
	out := make([]string, 0, len(argv)+len(flags))
	out = append(out, argv[:sep]...)
	out = append(out, flags...)
	return append(out, argv[sep:]...)
}
