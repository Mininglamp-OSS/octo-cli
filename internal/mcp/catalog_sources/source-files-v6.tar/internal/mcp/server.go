package mcp

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/Mininglamp-OSS/octo-cli/internal/cmdutil"
	"github.com/Mininglamp-OSS/octo-cli/internal/config"
	"github.com/Mininglamp-OSS/octo-cli/internal/credential"
	"github.com/Mininglamp-OSS/octo-cli/internal/output"
	"github.com/Mininglamp-OSS/octo-cli/internal/registry"
)

// defaultProtocolVersion is the single MCP protocol version this server
// implements and reports on initialize (it does not echo an arbitrary
// client-supplied version).
const defaultProtocolVersion = "2025-06-18"

const (
	serverName    = "octo-cli"
	serverVersion = "0.1.0-mcp"
)

// facadeMode selects which tool surface a connection exposes. The three-tool
// facade (search_ops / describe_op / call_op) is the default and PR #177
// behaviour; the two-tool facade (get_skill / execute) is opt-in; both exposes
// the full set for controlled side-by-side comparison.
type facadeMode string

const (
	facadeThree facadeMode = "three"
	facadeTwo   facadeMode = "two"
	facadeBoth  facadeMode = "both"
)

// ParseFacade validates a facade selector, defaulting empty to three-tool.
func ParseFacade(s string) (facadeMode, bool) {
	switch s {
	case "", "three":
		return facadeThree, true
	case "two":
		return facadeTwo, true
	case "both":
		return facadeBoth, true
	default:
		return facadeThree, false
	}
}

// Server handles MCP JSON-RPC requests for one connection. search_ops and
// describe_op read the registry directly; call_op drives the generated cobra
// tree via build. trusted carries the connection-scoped over-privilege-
// protection values; credentialToken, when set (HTTP), pins call_op to that
// bearer instead of the process env (stdio). baseGlobals carries the operator's
// parsed serve-time globals (credential selector + limits) into each call.
type Server struct {
	admission       *Admission
	apiOrigin       string
	secretDownloads *SecretDownloads
	reg             *registry.Registry
	mapping         *Mapping
	build           RootBuilder

	trusted          TrustedContext
	credentialToken  string                                     // "" → resolve from env (stdio) unless httpMode
	httpMode         bool                                       // HTTP connection: never inherit the server env credential
	uploadRoot       string                                     // OCTO_MCP_UPLOAD_ROOT; confines multipart file_path (both transports)
	allowLocalUpload bool                                       // operator --allow-local-upload: unconfined stdio upload pass-through
	uploadOpener     func(string, execPolicy) (*os.File, error) // optional internal upload-boundary observer
	baseGlobals      cmdutil.GlobalOptions                      // operator serve-time globals (BotID/Profile/Timeout/NoRetry/DryRun)

	protocolVersion string
	clientResources bool

	// facade selects the exposed tool surface ("" == three-tool default).
	facade facadeMode

	// factoryFn builds the per-call factory; nil means makeFactory. Tests set it
	// to point call_op at a fake backend.
	factoryFn func(TrustedContext) (*cmdutil.Factory, *bytes.Buffer, *bytes.Buffer)

	mu sync.Mutex // serialize call_op assembly per connection
}

// NewServer builds a connection server. It fails if the embedded skill
// navigation mapping is invalid (fail-fast).
func NewServer(build RootBuilder) (*Server, error) {
	reg, err := registry.New()
	if err != nil {
		return nil, err
	}
	mapping, err := BuildMapping(reg)
	if err != nil {
		return nil, err
	}
	return &Server{
		reg:             reg,
		mapping:         mapping,
		build:           build,
		protocolVersion: defaultProtocolVersion,
	}, nil
}

// WithTrustedContext pins the connection's forced values.
func (s *Server) WithTrustedContext(tc TrustedContext) *Server { s.trusted = tc; return s }

// WithBaseGlobals carries the operator's parsed serve-time globals (credential
// selector + limits) into each call_op.
func (s *Server) WithBaseGlobals(g cmdutil.GlobalOptions) *Server { s.baseGlobals = g; return s } //nolint:gocritic // copy serve-time globals for connection isolation

// WithUploadPolicy sets the multipart file_path confinement for this connection:
// root is OCTO_MCP_UPLOAD_ROOT (confine when set); allowLocal is the operator
// --allow-local-upload opt-in (unconfined stdio pass-through, ignored on HTTP).
func (s *Server) WithUploadPolicy(root string, allowLocal bool) *Server {
	s.uploadRoot = root
	s.allowLocalUpload = allowLocal
	return s
}

// WithFacade selects the exposed tool surface for this connection.
func (s *Server) WithFacade(f facadeMode) *Server { s.facade = f; return s }

// toolList returns the tools/list surface for the active facade.
func (s *Server) toolList() []toolDef {
	var tools []toolDef
	switch s.facade {
	case facadeTwo:
		tools = twoToolDefinitions()
	case facadeBoth:
		tools = append(toolDefinitions(), twoToolDefinitions()...)
	default:
		tools = toolDefinitions()
	}
	return append(tools, secretToolDefinition())
}

// WithSecretDownloads sets the shared publication and retrieval service.
func (s *Server) WithSecretDownloads(d *SecretDownloads) *Server { s.secretDownloads = d; return s }

// toolEnabled reports whether a tool name is callable under the active facade,
// so a tool from the other facade is a clean "unknown tool" rather than a
// silent cross-facade call.
func (s *Server) toolEnabled(name string) bool {
	if name == "get_secret_download_url" {
		return true
	}
	three := name == "search_ops" || name == "describe_op" || name == "call_op"
	two := name == "get_skill" || name == "execute"
	switch s.facade {
	case facadeTwo:
		return two
	case facadeBoth:
		return three || two
	default:
		return three
	}
}

// Facade-aware recovery hints. Under --facade two the three meta-tools are NOT
// exposed, so an error/degradation hint must never tell a caller to invoke the
// disabled search_ops / describe_op; it routes to get_skill with the right
// intent instead. Under three/both the wording is unchanged (no regression).
func (s *Server) discoveryToolName() string {
	if s.facade == facadeTwo {
		return "get_skill"
	}
	return "search_ops"
}

func (s *Server) hintDiscover() string {
	if s.facade == facadeTwo {
		return "call get_skill with intent=search to discover operation ids"
	}
	return "call search_ops to discover operation ids"
}

func (s *Server) hintDescribe() string {
	if s.facade == facadeTwo {
		return "call get_skill with intent=describe to see the operation's declared arguments"
	}
	return "call describe_op to see the operation's declared arguments"
}

func (s *Server) hintModuleMap() string {
	if s.facade == facadeTwo {
		return "call get_skill with intent=search and no domain/query for the module map"
	}
	return "call search_ops with no arguments for the module map"
}

// resourceDegradeHint is the no-resources-support fallback, worded per facade so
// a --facade two caller is pointed at get_skill describe, not describe_op.
func (s *Server) resourceDegradeHint(skillName string) string {
	proceed := "proceed with describe_op alone"
	if s.facade == facadeTwo {
		proceed = "proceed with get_skill intent=describe alone"
	}
	return "client has no MCP resources support; run `octo-cli skills " + skillName + "` if a shell is available, or " + proceed
}

// makeFactory builds a fresh factory with buffered IO for one call_op, applying
// the connection credential and the operator globals. A fresh factory per call
// keeps credentials and cached clients isolated between connections. The
// globals set here are re-applied after build() by executeOperation (build
// resets the fresh root's persistent flags).
//
// HTTP connections fail closed: the credential is pinned to the connection's
// bearer, and a missing/malformed bearer yields a CredentialFunc that returns
// an auth error — an HTTP call can NEVER inherit the server process env /
// auth-store credential. Only stdio (the local/trusted transport) resolves from
// the environment. reg is shared read-only with the connection so a call_op
// does not re-parse ~600 KB of embedded specs.
func (s *Server) makeFactory(tc TrustedContext) (*cmdutil.Factory, *bytes.Buffer, *bytes.Buffer) { //nolint:gocritic // factory callback signature is shared with test overrides
	streams, _, outBuf, errBuf := cmdutil.NewTestIOStreams()
	f := cmdutil.NewDefaultFactory()
	f.IOStreams = streams
	reg := s.reg
	f.RegistryFunc = func() *registry.Registry { return reg }
	// Operator-set routing/limit/safety globals; re-applied post-build by executeOperation.
	f.Globals.BotID = s.baseGlobals.BotID
	f.Globals.Profile = s.baseGlobals.Profile
	f.Globals.Timeout = s.baseGlobals.Timeout
	f.Globals.NoRetry = s.baseGlobals.NoRetry
	f.Globals.DryRun = s.baseGlobals.DryRun
	f.Globals.Space = tc.SpaceID
	if s.apiOrigin != "" {
		f.ConfigFunc = func() (*config.Config, error) { return &config.Config{APIBaseURL: s.apiOrigin}, nil }
	}
	if s.httpMode {
		tok := s.credentialToken
		space := tc.SpaceID
		f.CredentialFunc = func() (*credential.BotCredential, error) {
			if strings.TrimSpace(tok) == "" {
				return nil, output.ErrAuth(
					"missing or malformed Authorization bearer on the MCP HTTP connection",
					"send Authorization: Bearer <token>; the HTTP transport never inherits the server's own credential")
			}
			return &credential.BotCredential{
				Token:   tok,
				SpaceID: space,
				BotKind: credential.TokenKind(tok),
				Source:  "mcp:connection",
			}, nil
		}
	}
	return f, outBuf, errBuf
}

// Dispatch handles one JSON-RPC message and returns the response plus whether
// there is one. A JSON-RPC notification (no id) NEVER receives a response, for
// any method, so the id check comes first.
func (s *Server) Dispatch(ctx context.Context, req rpcRequest) (rpcResponse, bool) { //nolint:gocritic,gocyclo // immutable RPC snapshot with one branch per accepted protocol method
	if !validRPCID(req.ID) {
		return newErrorResponse(nil, codeInvalidRequest, "INVALID_REQUEST"), true
	}
	if req.isNotification() {
		meta, err := paramsMeta(req.Params)
		if err != nil {
			return rpcResponse{}, false
		}
		if _, err = parseDeclaredSource(meta); err != nil {
			return rpcResponse{}, false
		}
		return rpcResponse{}, false
	}
	if req.Jsonrpc != jsonrpcVersion && req.Jsonrpc != "" {
		return newErrorResponse(req.ID, codeInvalidRequest, "unsupported jsonrpc version"), true
	}
	if req.Method != "tools/call" {
		switch req.Method {
		case "initialize", "ping", "tools/list", "resources/list", "resources/read":
			if s.trusted.OnBehalfOf != "" {
				return admissionResponse(req.ID, admissionFailure(-32005, "OBO_FORBIDDEN")), true
			}
			if s.httpMode {
				if _, _, _, _, err := s.verify(ctx, false); err != nil {
					return admissionResponse(req.ID, err), true
				}
			}
			meta, err := paramsMeta(req.Params)
			if err == nil {
				_, err = parseDeclaredSource(meta)
			}
			if err != nil {
				return admissionResponse(req.ID, err), true
			}
		}
	}
	switch req.Method {
	case "initialize":
		return newResultResponse(req.ID, s.handleInitialize(req.Params)), true
	case "ping":
		return newResultResponse(req.ID, map[string]any{}), true
	case "tools/list":
		return newResultResponse(req.ID, map[string]any{"tools": s.toolList()}), true
	case "tools/call":
		return s.handleToolCall(ctx, req), true
	case "resources/list":
		return newResultResponse(req.ID, s.listResources()), true
	case "resources/read":
		return s.handleResourceRead(req), true
	default:
		return newErrorResponse(req.ID, codeMethodNotFound, "METHOD_NOT_FOUND"), true
	}
}

func (s *Server) handleInitialize(params json.RawMessage) map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	var p struct {
		ProtocolVersion string `json:"protocolVersion"`
		Capabilities    struct {
			Resources json.RawMessage `json:"resources"`
		} `json:"capabilities"`
	}
	if len(params) > 0 {
		_ = json.Unmarshal(params, &p) //nolint:errcheck // optional initialize metadata is best-effort
	}
	// Pin the negotiated version to what this server implements rather than
	// echoing an arbitrary client string: the server supports exactly this
	// protocol version, and an incompatible client fails loudly at the method
	// layer instead of negotiating a version nobody implements.
	s.protocolVersion = defaultProtocolVersion
	s.clientResources = len(p.Capabilities.Resources) > 0
	return map[string]any{
		"protocolVersion": s.protocolVersion,
		"capabilities": map[string]any{
			"tools":     map[string]any{},
			"resources": map[string]any{},
		},
		"serverInfo": map[string]any{"name": serverName, "version": serverVersion},
	}
}

type toolCallParams struct {
	Name      string          `json:"name"`
	Arguments json.RawMessage `json:"arguments"`
	Meta      json.RawMessage `json:"_meta,omitempty"`
}

func (s *Server) handleToolCall(ctx context.Context, req rpcRequest) rpcResponse { //nolint:gocritic,gocyclo // request snapshot is immutable during dispatch; one branch per tool
	var p toolCallParams
	if err := decodeToolCallParams(req.Params, &p); err != nil {
		return newErrorResponse(req.ID, codeInvalidParams, "invalid tools/call params: "+err.Error())
	}
	if !s.toolEnabled(p.Name) {
		return newErrorResponse(req.ID, codeInvalidParams, "unknown tool")
	}
	// An arguments value that is present but not a JSON object is an invalid
	// shape: return -32602 rather than silently degrading to empty args.
	if len(p.Arguments) > 0 && !isJSONObject(p.Arguments) {
		return newErrorResponse(req.ID, codeInvalidParams, "tool arguments must be a JSON object")
	}
	var shapeErr error
	switch p.Name {
	case "execute":
		shapeErr = validateExecuteKeys(p.Arguments)
	case "call_op":
		shapeErr = validateClosedKeys(p.Arguments, callOpArgumentNames)
	case "get_skill":
		shapeErr = validateClosedKeys(p.Arguments, getSkillArgumentNames)
	}
	if shapeErr != nil {
		return newErrorResponse(req.ID, codeInvalidParams, "invalid "+p.Name+" arguments: "+shapeErr.Error())
	}
	if p.Name == "execute" || p.Name == "call_op" {
		var wrapper struct {
			Arguments json.RawMessage `json:"arguments"`
		}
		if err := json.Unmarshal(p.Arguments, &wrapper); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid operation arguments")
		}
		var basicErr error
		if ctx.Err() != nil {
			basicErr = errArgumentsCancelled{ctx.Err()}
		} else if isJSONObject(wrapper.Arguments) {
			count := 0
			basicErr = visitObjectMembers(wrapper.Arguments, func(string, json.RawMessage) error {
				count++
				if count%64 == 0 && ctx.Err() != nil {
					return errArgumentsCancelled{ctx.Err()}
				}
				return nil
			})
			if basicErr == nil && count > maxArgumentNames {
				basicErr = fmt.Errorf("too many arguments: %d names exceed the limit of %d", count, maxArgumentNames)
			}
		}
		if basicErr != nil {
			ee := argvError(basicErr, "")
			env := synthErrorEnvelope(ee)
			if p.Name == "execute" {
				return newResultResponse(req.ID, jsonToolResult(map[string]any{"status": "validation_error", "envelope": decodeEnvelope(env), "error": ee}, true))
			}
			return newResultResponse(req.ID, rawToolResult(env, true))
		}
	}
	ctx, cancel := context.WithTimeout(ctx, 120*time.Second)
	defer cancel()
	received := req.receivedAt
	if received.IsZero() {
		received = time.Now()
	}
	call, release, err := s.admitToolCall(ctx, req, p, received)
	if err != nil {
		return admissionResponse(req.ID, err)
	}
	defer release()
	if ctx.Err() != nil {
		return admissionResponse(req.ID, logUnavailable())
	}
	return call.handleAdmittedToolCall(ctx, req, p)
}

func (s *Server) handleAdmittedToolCall(ctx context.Context, req rpcRequest, p toolCallParams) rpcResponse { //nolint:gocritic,gocyclo // immutable request snapshots are copied at this boundary; one branch per admitted facade tool
	switch p.Name {
	case "get_secret_download_url":
		return newResultResponse(req.ID, s.secretDownloadTool(ctx, p.Arguments))
	case "search_ops":
		var a struct {
			Domain string `json:"domain"`
			Query  string `json:"query"`
		}
		if err := unmarshalArgs(p.Arguments, &a); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid search_ops arguments: "+err.Error())
		}
		return newResultResponse(req.ID, s.searchOps(ctx, a.Domain, a.Query))
	case "describe_op":
		var a struct {
			OperationID string `json:"operation_id"`
		}
		if err := unmarshalArgs(p.Arguments, &a); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid describe_op arguments: "+err.Error())
		}
		if a.OperationID == "" {
			return newResultResponse(req.ID, jsonToolResult(missingArg("operation_id"), true))
		}
		return newResultResponse(req.ID, s.describeOp(a.OperationID))
	case "call_op":
		if err := validateClosedKeys(p.Arguments, callOpArgumentNames); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid call_op arguments: "+err.Error())
		}
		var a struct {
			OperationID string          `json:"operation_id"`
			Arguments   json.RawMessage `json:"arguments"`
		}
		if err := unmarshalArgs(p.Arguments, &a); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid call_op arguments: "+err.Error())
		}
		if a.OperationID == "" {
			return newResultResponse(req.ID, jsonToolResult(missingArg("operation_id"), true))
		}
		if len(a.Arguments) > 0 && !isJSONObject(a.Arguments) {
			return newErrorResponse(req.ID, codeInvalidParams, "call_op arguments must be a JSON object")
		}
		args, err := decodeArgs(a.Arguments)
		if err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "call_op arguments must be a JSON object: "+err.Error())
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		return newResultResponse(req.ID, s.callOp(ctx, a.OperationID, args))
	case "get_skill":
		if err := validateClosedKeys(p.Arguments, getSkillArgumentNames); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid get_skill arguments: "+err.Error())
		}
		var a struct {
			Intent      string `json:"intent"`
			Domain      string `json:"domain"`
			Query       string `json:"query"`
			OperationID string `json:"operation_id"`
			Depth       string `json:"depth"`
		}
		if err := unmarshalArgs(p.Arguments, &a); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid get_skill arguments: "+err.Error())
		}
		return newResultResponse(req.ID, s.getSkill(ctx, a.Intent, a.Domain, a.Query, a.OperationID, a.Depth))
	case "execute":
		if err := validateExecuteKeys(p.Arguments); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid execute arguments: "+err.Error())
		}
		var a struct {
			OperationID       string          `json:"operation_id"`
			Arguments         json.RawMessage `json:"arguments"`
			DryRun            bool            `json:"dry_run"`
			SchemaFingerprint string          `json:"schema_fingerprint"`
		}
		if err := unmarshalArgs(p.Arguments, &a); err != nil {
			return newErrorResponse(req.ID, codeInvalidParams, "invalid execute arguments: "+err.Error())
		}
		if a.OperationID == "" {
			return newResultResponse(req.ID, jsonToolResult(map[string]any{
				"status": "validation_error",
				"error":  map[string]any{"type": "validation", "code": "VALIDATION_ERROR", "message": "missing required argument operation_id"},
			}, true))
		}
		if len(a.Arguments) > 0 && !isJSONObject(a.Arguments) {
			return newErrorResponse(req.ID, codeInvalidParams, "execute arguments must be a JSON object")
		}
		args, err := decodeArgs(a.Arguments)
		if err != nil {
			return newResultResponse(req.ID, jsonToolResult(map[string]any{
				"status": "validation_error",
				"error":  map[string]any{"type": "validation", "code": "INVALID_ARGUMENTS", "message": err.Error()},
			}, true))
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		return newResultResponse(req.ID, s.execute(ctx, a.OperationID, args, a.DryRun, a.SchemaFingerprint))
	default:
		return newErrorResponse(req.ID, codeInvalidParams, "unknown tool: "+p.Name)
	}
}

// validateToolCallKeys checks the tools/call params object before struct
// decoding can drop or merge keys. Only name, arguments and _meta are accepted,
// with their exact spelling and at most once each, so a misplaced safety field
// such as params.dry_run, or a second arguments object, is refused instead of
// being silently discarded while the call runs live.
func decodeToolCallParams(raw json.RawMessage, p *toolCallParams) error {
	if len(raw) == 0 {
		return nil
	}
	if !isJSONObject(raw) {
		return json.Unmarshal(raw, p)
	}
	seen := map[string]bool{}
	return visitObjectMembers(raw, func(key string, value json.RawMessage) error {
		if key != "name" && key != "arguments" && key != "_meta" {
			return fmt.Errorf("unknown field %q; tool inputs belong inside arguments", truncateRunes(key, 200))
		}
		if seen[key] {
			return fmt.Errorf("duplicate field %q", key)
		}
		seen[key] = true
		switch key {
		case "name":
			return json.Unmarshal(value, &p.Name)
		case "arguments":
			p.Arguments = value
		case "_meta":
			p.Meta = value
		}
		return nil
	})
}

// getSkillArgumentNames is get_skill's closed argument set; a misspelled
// depth or operation_id must not silently fall back to its default.
var getSkillArgumentNames = map[string]bool{"intent": true, "domain": true, "query": true, "operation_id": true, "depth": true}

// callOpArgumentNames is call_op's closed argument set. call_op has no dry_run
// or schema_fingerprint switch, so such a key next to operation_id must be
// refused rather than dropped while the operation is sent live.
var callOpArgumentNames = map[string]bool{"operation_id": true, "arguments": true}

// validateClosedKeys refuses an unknown, mis-cased or repeated key in a tool's
// arguments object before struct decoding would ignore or merge it.
func validateClosedKeys(raw json.RawMessage, allowed map[string]bool) error {
	if len(raw) == 0 || !isJSONObject(raw) {
		return nil
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	if _, err := d.Token(); err != nil {
		return err
	}
	seen := map[string]bool{}
	for d.More() {
		token, err := d.Token()
		if err != nil {
			return err
		}
		key, _ := token.(string)
		if !allowed[key] {
			return fmt.Errorf("unknown argument %q", truncateRunes(key, 200))
		}
		if seen[key] {
			return fmt.Errorf("duplicate argument %q", key)
		}
		seen[key] = true
		var value json.RawMessage
		if err := d.Decode(&value); err != nil {
			return err
		}
	}
	_, err := d.Token()
	return err
}

// validateExecuteKeys keeps safety switches fail-closed. Struct unmarshalling
// alone ignores unknown keys, accepts case-insensitive names, and maps null to
// scalar zero values. Duplicate keys can also overwrite an earlier dry-run.
// Only this tool's outer object is strict; operation arguments remain governed
// by the shared registry/schema validator.
func validateExecuteKeys(raw json.RawMessage) error {
	if len(raw) == 0 {
		return nil
	}
	d := json.NewDecoder(bytes.NewReader(raw))
	if _, err := d.Token(); err != nil {
		return err
	}
	seen := map[string]bool{}
	for d.More() {
		token, err := d.Token()
		if err != nil {
			return err
		}
		key, ok := token.(string)
		if !ok {
			return fmt.Errorf("expected an argument name")
		}
		switch key {
		case "operation_id", "arguments", "dry_run", "schema_fingerprint":
		default:
			return fmt.Errorf("unknown argument %q", truncateRunes(key, 200))
		}
		if seen[key] {
			return fmt.Errorf("duplicate argument %q", truncateRunes(key, 200))
		}
		seen[key] = true
		var value json.RawMessage
		if err := d.Decode(&value); err != nil {
			return err
		}
		if bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return fmt.Errorf("argument %q must not be null", key)
		}
	}
	_, err := d.Token()
	return err
}

// unmarshalArgs decodes the tool arguments object, treating an empty/omitted
// value as an empty object rather than an error.
func unmarshalArgs(raw json.RawMessage, v any) error {
	if len(raw) == 0 {
		return nil
	}
	return json.Unmarshal(raw, v)
}

// isJSONObject reports whether raw is a JSON object (first non-space byte '{').
func isJSONObject(raw json.RawMessage) bool {
	for _, b := range raw {
		switch b {
		case ' ', '\t', '\n', '\r':
			continue
		}
		return b == '{'
	}
	return false
}

func (s *Server) handleResourceRead(req rpcRequest) rpcResponse { //nolint:gocritic // request snapshot is immutable during dispatch
	var a struct {
		URI string `json:"uri"`
	}
	if err := json.Unmarshal(req.Params, &a); err != nil {
		return newErrorResponse(req.ID, codeInvalidParams, "invalid resources/read params: "+err.Error())
	}
	res, err := s.readResource(a.URI)
	if err != nil {
		return newErrorResponse(req.ID, codeInvalidParams, err.Error())
	}
	return newResultResponse(req.ID, res)
}

// decodeArgs decodes the call_op arguments object with UseNumber so a uint64 id
// keeps its exact decimal text rather than rounding through float64.
func decodeArgs(raw json.RawMessage) (map[string]any, error) {
	if len(raw) == 0 {
		return map[string]any{}, nil
	}
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var out map[string]any
	if err := dec.Decode(&out); err != nil {
		return nil, err
	}
	if out == nil {
		out = map[string]any{}
	}
	return out, nil
}

func missingArg(name string) map[string]any {
	return map[string]any{"ok": false, "error": map[string]any{
		"type": "validation", "code": "VALIDATION_ERROR",
		"message": "missing required argument " + name,
	}}
}
