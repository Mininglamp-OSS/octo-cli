// Package cmdutil contains the command-layer DI container (Factory) and shared
// command-runtime helpers. Commands receive a *Factory and resolve everything
// else — config, client, credential, io streams — through it.
package cmdutil

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"

	"github.com/Mininglamp-OSS/octo-cli/internal/authstore"
	"github.com/Mininglamp-OSS/octo-cli/internal/client"
	"github.com/Mininglamp-OSS/octo-cli/internal/config"
	"github.com/Mininglamp-OSS/octo-cli/internal/credential"
	"github.com/Mininglamp-OSS/octo-cli/internal/output"
	"github.com/Mininglamp-OSS/octo-cli/internal/registry"
)

// GlobalOptions holds the values of root-level persistent flags that command
// RunE functions need to consult. Populated by the root command before
// dispatch. Zero values are meaningful defaults (e.g. Format="" → json).
type GlobalOptions struct {
	Format  string
	JQ      string
	DryRun  bool
	Verbose bool
	Timeout string // raw string; parsed where used
	NoRetry bool
	Space   string
	PageAll bool
	PageMax int

	// Profile and BotID are explicit stored-profile selectors. When BotID is
	// empty, OCTO_BOT_ID may instead label an environment credential if the
	// profile store is empty.
	Profile string
	BotID   string
}

// Factory is the DI container. All accessors are lazy + cached so a command
// can ask for only what it needs. The hooks (ConfigFunc, CredentialFunc etc.)
// are exposed so tests can substitute stubs without touching the environment.
type Factory struct {
	IOStreams *IOStreams
	Globals   *GlobalOptions

	// MultipartFile is a caller-owned, already-open upload descriptor. When
	// supplied, multipart assembly reads it instead of reopening --file.
	// The caller closes it after execution; ordinary CLI calls leave it nil.
	MultipartFile *os.File

	// InlineBinaryLimit, when positive, asks binary-response operations run
	// without --output to return bodies up to this many bytes inside the
	// envelope (see client.Request.InlineBinaryLimit). The MCP server sets it;
	// ordinary CLI calls leave it zero and keep the describe-only behaviour.
	InlineBinaryLimit int64

	// GeneratedDriveShareLeaves keeps the spec-generated `drive share
	// blob-create|access|download` leaves instead of replacing them with the
	// hand-written composites. The MCP server sets it so those operations are
	// callable with exactly the schema get_skill/describe_op publishes.
	GeneratedDriveShareLeaves bool

	ConfigFunc         func() (*config.Config, error)
	CredentialFunc     func() (*credential.BotCredential, error)
	ClientFunc         func() (*client.Client, error)
	MailCredentialFunc func(context.Context) (*credential.MailCredential, error)
	MailClientFunc     func(context.Context) (*client.Client, error)
	RegistryFunc       func() *registry.Registry

	// ErrorEmitted is set to true after EmitError writes an envelope to
	// stderr. The top-level main func checks this to avoid double-emitting
	// when RunE returns the same error that was already rendered.
	ErrorEmitted bool

	// Cached resolutions.
	config   *config.Config
	cred     *credential.BotCredential
	cli      *client.Client
	mailCred *credential.MailCredential
	mailCLI  *client.Client
	// Compiled output query, paired with its expression for safe Factory reuse.
	jqExpression string
	jqProgram    *output.JQProgram
	// botIdentityVerified records that the active Bot id is trusted: either it
	// was obtained from the authoritative registration endpoint or recovered
	// from an exact local Mail binding for the active Bot-token fingerprint.
	botIdentityVerified bool
	reg                 *registry.Registry
	store               *authstore.Store
}

// NewDefaultFactory wires the production providers: config from env, cred from
// env chain, client built from both. IO defaults to stdio. Callers (root cmd)
// inject the global options after parsing flags.
func NewDefaultFactory() *Factory {
	f := &Factory{
		IOStreams: NewStdIOStreams(),
		Globals:   &GlobalOptions{},
	}

	f.ConfigFunc = func() (*config.Config, error) {
		if f.config != nil {
			return f.config, nil
		}
		cfg, err := f.buildConfig()
		if err != nil {
			return nil, err
		}
		f.config = cfg
		return cfg, nil
	}

	f.CredentialFunc = func() (*credential.BotCredential, error) {
		if f.cred != nil {
			return f.cred, nil
		}
		cred, err := f.buildCredential()
		if err != nil {
			return nil, err
		}
		f.cred = cred
		return cred, nil
	}

	f.ClientFunc = func() (*client.Client, error) {
		if f.cli != nil {
			return f.cli, nil
		}
		cfg, err := f.ConfigFunc()
		if err != nil {
			return nil, err
		}
		cred, err := f.CredentialFunc()
		if err != nil {
			return nil, err
		}
		cli := client.New(cfg, cred, client.Options{
			Verbose: f.Globals.Verbose,
			DryRun:  f.Globals.DryRun,
			NoRetry: f.Globals.NoRetry,
			Timeout: f.Globals.Timeout,
			ErrOut:  f.IOStreams.ErrOut,
		})
		f.cli = cli
		return cli, nil
	}

	configureMailProviders(f)

	f.RegistryFunc = func() *registry.Registry {
		if f.reg != nil {
			return f.reg
		}
		// Specs are embedded; parse failure is a build-time bug.
		f.reg = registry.MustNew()
		return f.reg
	}

	return f
}

func configureMailProviders(f *Factory) {
	f.MailCredentialFunc = func(ctx context.Context) (*credential.MailCredential, error) {
		if f.mailCred != nil {
			return f.mailCred, nil
		}
		// Mail credentials are stored under RobotID + SpaceID + fingerprints of
		// the API origin and Bot token that completed authorization. Exact lookup
		// therefore releases no mailbox credential after an origin or token swap
		// and needs no live Bot registration call on each command (including
		// --dry-run).
		bot, err := f.CredentialFunc()
		if err != nil {
			return nil, err
		}
		cfg, err := f.ConfigFunc()
		if err != nil {
			return nil, err
		}
		store, err := f.AuthStore()
		if err != nil {
			return nil, err
		}
		token, binding, err := storedMailCredential(store, bot, cfg.APIBaseURL)
		if err != nil {
			if errors.Is(err, authstore.ErrMailCredentialNotFound) {
				return nil, output.ErrValidation(
					"Agent Mail is not connected for the active Bot",
					"complete Agent Mail authorization for the current Bot",
				)
			}
			if errors.Is(err, authstore.ErrMailCredentialAmbiguous) {
				return nil, output.ErrValidation(
					"multiple Agent Mail connections match the active Bot",
					"pass --space <space_id> to select one",
				)
			}
			return nil, err
		}
		bot.RobotID = binding.RobotID
		bot.SpaceID = binding.SpaceID
		f.cred = bot
		f.botIdentityVerified = true
		f.mailCred = &credential.MailCredential{
			Token: token, BotID: bot.RobotID, BotProfile: bot.Profile,
			Source: "bot:" + binding.RobotID + "/" + binding.SpaceID,
		}
		return f.mailCred, nil
	}

	f.MailClientFunc = func(ctx context.Context) (*client.Client, error) {
		if f.mailCLI != nil {
			return f.mailCLI, nil
		}
		cfg, err := f.ConfigFunc()
		if err != nil {
			return nil, err
		}
		cred, err := f.MailCredentialFunc(ctx)
		if err != nil {
			return nil, err
		}
		cli := client.NewMail(cfg, cred, client.Options{
			Verbose: f.Globals.Verbose,
			DryRun:  f.Globals.DryRun,
			NoRetry: f.Globals.NoRetry,
			Timeout: f.Globals.Timeout,
			ErrOut:  f.IOStreams.ErrOut,
		})
		f.mailCLI = cli
		return cli, nil
	}
}

// buildConfig loads the env config and reflects the resolved credential into it
// so cfg.Validate (the auth gate in root's PersistentPreRunE) passes for
// profile-based use and config show reports the active token. Only the "no
// credential found" case outside task mode is swallowed (so cfg.Validate
// reports the familiar OCTO_BOT_TOKEN hint for the zero-config case); task-mode
// resolution errors retain their task-specific guidance. Structured errors
// (ambiguous / missing profile) AND real IO errors (home dir, salt read) both
// surface rather than masquerading as a missing token.
func (f *Factory) buildConfig() (*config.Config, error) {
	cfg := config.Load()
	if f.Globals.Format != "" {
		cfg.Format = f.Globals.Format
	}
	cred, err := f.CredentialFunc()
	if err != nil {
		if errors.Is(err, credential.ErrNoCredential) && cfg.CredentialMode != config.CredentialModeTask {
			return cfg, nil
		}
		return nil, err
	}
	if cred != nil {
		if cred.Token != "" {
			cfg.BotToken = cred.Token
		}
		if cred.SpaceID != "" {
			cfg.SpaceID = cred.SpaceID
		}
		if err := f.overlayProfileBaseURL(cfg, cred.Profile); err != nil {
			return nil, err
		}
	}
	return cfg, nil
}

// buildCredential selects explicit profiles first, then normalized environment
// credentials, then implicit stored profiles. Mail uses the same resolved identity.
func (f *Factory) buildCredential() (*credential.BotCredential, error) {
	mode := strings.ToLower(strings.TrimSpace(os.Getenv(config.EnvCredentialMode)))
	if mode == config.CredentialModeTask {
		return f.buildTaskCredential()
	}
	if mode != "" {
		return nil, fmt.Errorf("unsupported %s %q", config.EnvCredentialMode, mode)
	}

	hasExplicitSelector := f.Globals.Profile != "" || f.Globals.BotID != ""
	if !hasExplicitSelector {
		cred, err := credential.NewEnvProvider().Resolve()
		if err != nil {
			return nil, err
		}
		if cred != nil {
			return f.finalizeCredential(cred), nil
		}
	}

	store, err := f.AuthStore()
	if err != nil {
		return nil, err
	}
	botID := f.Globals.BotID
	if botID == "" {
		botID = strings.TrimSpace(os.Getenv(config.EnvBotID))
	}
	chain := credential.NewChain(credential.NewFileProvider(store, f.Globals.Profile, botID))
	cred, err := chain.Resolve()
	if err != nil {
		return nil, err
	}
	return f.finalizeCredential(cred), nil
}

func (f *Factory) finalizeCredential(cred *credential.BotCredential) *credential.BotCredential {
	if f.Globals.Space != "" {
		cred.SpaceID = f.Globals.Space
	}
	if cred.BotKind == "" {
		cred.BotKind = credential.TokenKind(cred.Token)
	}
	return cred
}

func storedMailCredential(store *authstore.Store, bot *credential.BotCredential, apiOrigin string) (string, authstore.MailBinding, error) {
	if bot == nil {
		return "", authstore.MailBinding{}, errors.New("Bot credential is required") //nolint:staticcheck // Bot is the product's canonical identity term.
	}
	return store.FindMailCredential(
		strings.TrimSpace(bot.RobotID),
		strings.TrimSpace(bot.SpaceID),
		bot.Token,
		apiOrigin,
	)
}

// MailBindingKeyForBot derives the local credential-store key without
// persisting the Bot token itself. Mail authorization and Mail request paths
// share this helper so Space, origin, and token binding cannot drift between
// them.
func MailBindingKeyForBot(bot *credential.BotCredential, apiOrigin string) (string, error) {
	if bot == nil || strings.TrimSpace(bot.RobotID) == "" {
		return "", output.ErrValidation(
			"Agent Mail requires a resolved Bot id",
			"use a stored profile or set OCTO_BOT_ID for the runtime Bot",
		)
	}
	if strings.TrimSpace(bot.SpaceID) == "" {
		return "", output.ErrValidation(
			"Agent Mail requires a Space",
			"pass --space <space_id> or set OCTO_SPACE_ID",
		)
	}
	return authstore.MailBindingKey(bot.RobotID, bot.SpaceID, bot.Token, apiOrigin)
}

// buildTaskCredential consumes only the dedicated credential for an explicitly
// selected task invocation. The daemon provides its value; Fleet verifies the
// opaque bearer and enforces its principal, bindings and actions.
func (f *Factory) buildTaskCredential() (*credential.BotCredential, error) {
	if f.Globals.Profile != "" || f.Globals.BotID != "" ||
		strings.TrimSpace(os.Getenv(config.EnvBotID)) != "" {
		return nil, fmt.Errorf("%s=task does not allow --profile, --bot-id, or %s", config.EnvCredentialMode, config.EnvBotID)
	}
	if f.Globals.Space != "" {
		return nil, fmt.Errorf("%s=task does not allow --space; use the Loop command's --workspace-id", config.EnvCredentialMode)
	}
	resolved := config.ResolveEnvToken()
	if resolved.Token == "" {
		return nil, fmt.Errorf("%w: %s=task requires %s", credential.ErrNoCredential, config.EnvCredentialMode, config.EnvTaskToken)
	}
	return &credential.BotCredential{Token: resolved.Token, Source: resolved.Source, BotKind: "agent_task"}, nil
}

// AuthStore lazily constructs and caches the credential store.
func (f *Factory) AuthStore() (*authstore.Store, error) {
	if f.store != nil {
		return f.store, nil
	}
	s, err := authstore.New()
	if err != nil {
		return nil, err
	}
	f.store = s
	return s, nil
}

// overlayProfileBaseURL applies the active profile's stored API base URL.
// Precedence is profile > OCTO_API_BASE_URL > default: a profile that records
// an origin routes there even when the environment variable names another one.
func (f *Factory) overlayProfileBaseURL(cfg *config.Config, profile string) error {
	if profile == "" {
		return nil
	}
	store, err := f.AuthStore()
	if err != nil {
		return err
	}
	profiles, err := store.LoadProfiles()
	if err != nil {
		return err
	}
	if m, ok := profiles[profile]; ok && m.APIBaseURL != "" {
		normalized, err := config.NormalizeAPIBaseURL(m.APIBaseURL)
		if err != nil {
			return output.ErrValidation(
				fmt.Sprintf("profile %q has an invalid API base URL: %v", profile, err),
				fmt.Sprintf("repair it with `octo-cli --profile %s auth update --api-base-url <origin>` or remove it with `octo-cli --profile %s auth update --clear-api-base-url`", profile, profile),
			)
		}
		cfg.APIBaseURL = normalized
		cfg.APIBaseURLSource = "profile"
	}
	return nil
}

// Config returns the resolved config (cached).
func (f *Factory) Config() (*config.Config, error) { return f.ConfigFunc() }

// Credential returns the resolved credential (cached).
func (f *Factory) Credential() (*credential.BotCredential, error) { return f.CredentialFunc() }

// Client returns the resolved HTTP client (cached).
func (f *Factory) Client() (*client.Client, error) { return f.ClientFunc() }

// MailCredential returns the account-scoped Agent Mail credential.
func (f *Factory) MailCredential(ctx context.Context) (*credential.MailCredential, error) {
	if f.MailCredentialFunc == nil {
		return nil, output.ErrValidation(
			"Agent Mail credential provider is not configured",
			"complete Agent Mail authorization for the current Bot",
		)
	}
	return f.MailCredentialFunc(ctx)
}

// ClientForCredential returns the transport selected by an operation's
// credential boundary. Mail uses a Bot-bound mailbox credential; every
// other operation uses the active Bot credential.
func (f *Factory) ClientForCredential(ctx context.Context, kind string) (*client.Client, error) {
	if kind == "mail" {
		if f.MailClientFunc == nil {
			return nil, output.ErrValidation(
				"Agent Mail client is not configured",
				"complete Agent Mail authorization for the current Bot",
			)
		}
		return f.MailClientFunc(ctx)
	}
	return f.Client()
}

// ResolveBotIdentity returns the active Bot credential with a stable RobotID.
// Existing profiles already carry that id; token-only runtimes always resolve
// it from the standard Bot registration endpoint. An OCTO_BOT_ID supplied next
// to an environment token is only a claim until that endpoint confirms it.
func (f *Factory) ResolveBotIdentity(ctx context.Context) (*credential.BotCredential, error) {
	return f.resolveBotIdentity(ctx, false)
}

// VerifyBotIdentity resolves the authoritative Bot id even when the active
// profile already claims one. Device authorization uses this stricter path so
// a stale or incorrect profile can never bind a mailbox to another Bot.
func (f *Factory) VerifyBotIdentity(ctx context.Context) (*credential.BotCredential, error) {
	return f.resolveBotIdentity(ctx, true)
}

// BindVerifiedBotIdentity binds a private per-RPC factory after read-only remote
// verification. It never saves a profile and cannot be reached through flags.
func (f *Factory) BindVerifiedBotIdentity(expectedToken, expectedOrigin, uid string) error {
	bot, err := f.Credential()
	if err != nil || bot == nil || bot.Token != expectedToken || uid == "" {
		return output.ErrAuth("Bot snapshot mismatch", "")
	}
	cfg, err := f.Config()
	if err != nil || cfg == nil || cfg.APIBaseURL != expectedOrigin || (bot.RobotID != "" && bot.RobotID != uid) {
		return output.ErrAuth("Bot snapshot mismatch", "")
	}
	bc, cc := *bot, *cfg
	bc.RobotID = uid
	cc.BotToken = bc.Token
	f.cred, f.config, f.cli, f.botIdentityVerified = &bc, &cc, nil, true
	f.CredentialFunc = func() (*credential.BotCredential, error) { c := bc; return &c, nil }
	f.ConfigFunc = func() (*config.Config, error) { c := cc; return &c, nil }
	f.ClientFunc = func() (*client.Client, error) {
		return client.New(&cc, &bc, client.Options{DryRun: f.Globals.DryRun, NoRetry: f.Globals.NoRetry, Timeout: f.Globals.Timeout, ErrOut: io.Discard}), nil
	}
	return nil
}

func (f *Factory) resolveBotIdentity(ctx context.Context, verify bool) (*credential.BotCredential, error) {
	bot, err := f.CredentialFunc()
	if err != nil {
		return nil, err
	}
	if f.botIdentityVerified {
		return bot, nil
	}
	// A stored profile is the local identity selector used by ordinary
	// commands. A bare environment RobotID is different: it is caller input and
	// must not select a stored mailbox credential until OCTO confirms that the
	// active token owns it.
	if strings.TrimSpace(bot.RobotID) != "" && bot.Profile != "" && !verify {
		return bot, nil
	}
	if f.Globals != nil && f.Globals.DryRun {
		return nil, output.ErrValidation(
			"Bot identity verification is not executed during --dry-run",
			"provide a stored profile or OCTO_BOT_ID to preview the Mail request locally",
		)
	}
	cli, err := f.botIdentityClient()
	if err != nil {
		return nil, err
	}
	raw, err := cli.Do(ctx, &client.Request{
		Method: http.MethodPost,
		Path:   "/v1/bot/register",
		Body:   map[string]any{},
	})
	if err != nil {
		return nil, err
	}
	resolvedID, err := botIDFromResponse(raw)
	if err != nil {
		return nil, err
	}
	if claimedID := strings.TrimSpace(bot.RobotID); claimedID != "" && claimedID != resolvedID {
		return nil, output.ErrAuth(
			fmt.Sprintf("the active Bot token belongs to %q, not %q", resolvedID, claimedID),
			"select the credential that belongs to the current Bot",
		)
	}
	bot.RobotID = resolvedID
	f.cred = bot
	f.botIdentityVerified = true
	return bot, nil
}

func botIDFromResponse(raw []byte) (string, error) {
	var response struct {
		RobotID string `json:"robot_id"`
		Data    *struct {
			RobotID string `json:"robot_id"`
		} `json:"data,omitempty"`
	}
	if err := json.Unmarshal(raw, &response); err != nil {
		return "", output.ErrAPI(
			"INVALID_BOT_IDENTITY_RESPONSE",
			"OCTO returned an invalid Bot identity response",
			"retry the command",
		)
	}
	resolvedID := strings.TrimSpace(response.RobotID)
	if resolvedID == "" && response.Data != nil {
		resolvedID = strings.TrimSpace(response.Data.RobotID)
	}
	if resolvedID == "" {
		return "", output.ErrAPI(
			"INVALID_BOT_IDENTITY_RESPONSE",
			"OCTO did not return the current Bot id",
			"check the Bot token and OCTO API endpoint",
		)
	}
	return resolvedID, nil
}

// botIdentityClient uses the ordinary client options. resolveBotIdentity blocks
// this path under --dry-run, so a preview never bypasses the global no-network
// contract by constructing a second live client.
func (f *Factory) botIdentityClient() (*client.Client, error) {
	return f.ClientFunc()
}

// Registry returns the spec registry (cached). Tests may inject a stub by
// replacing RegistryFunc.
func (f *Factory) Registry() *registry.Registry {
	if f.RegistryFunc == nil {
		return nil
	}
	return f.RegistryFunc()
}

// Format returns the effective output format (CLI flag > env/config default).
func (f *Factory) Format() string {
	if f.Globals != nil && f.Globals.Format != "" {
		return f.Globals.Format
	}
	if cfg, err := f.Config(); err == nil {
		return cfg.Format
	}
	return output.FormatJSON
}

// PreflightOutput validates the already-resolved output format and compiles
// --jq before a command performs any work. The compiled program is reused by
// emit and keyed by its source expression so factories can safely run more
// than one root command.
func (f *Factory) PreflightOutput(format string) error {
	expr := ""
	if f.Globals != nil {
		expr = f.Globals.JQ
	}
	if expr == "" {
		f.jqExpression = ""
		f.jqProgram = nil
	} else if f.jqProgram == nil || f.jqExpression != expr {
		program, err := output.CompileJQ(expr)
		if err != nil {
			return err
		}
		f.jqExpression = expr
		f.jqProgram = program
	}
	return output.ValidateFormat(format)
}

// EmitSuccess renders a success envelope, applying --jq first (if set) and
// then the configured output format. Non-nil raw is placed inside the envelope.
func (f *Factory) EmitSuccess(raw []byte) error {
	rm := normalizeRaw(raw)
	return f.emit(rm, output.EnvelopeMeta{})
}

// EmitSuccessWithMeta is EmitSuccess plus envelope meta (rate limit, notice).
func (f *Factory) EmitSuccessWithMeta(raw []byte, meta output.EnvelopeMeta) error {
	return f.emit(normalizeRaw(raw), meta)
}

// identityValue builds the envelope's identity field from the credential
// resolved during the command. It only inspects the already-cached credential
// (never forces resolution), so commands that don't authenticate keep the plain
// "bot" tag. Returns nil to mean "use the default".
func (f *Factory) identityValue() any {
	if f.cred == nil {
		return nil
	}
	identityType := "bot"
	if f.cred.BotKind == "agent_task" {
		identityType = "agent_task"
	}
	id := map[string]any{"type": identityType}
	if f.cred.Profile != "" {
		id["profile"] = f.cred.Profile
	}
	if f.cred.RobotID != "" {
		// A RobotID from OCTO_BOT_ID is caller-supplied until an authoritative
		// lookup confirms it. Keep the claim observable without presenting it as
		// the authenticated identity.
		if f.cred.Profile != "" || f.botIdentityVerified {
			id["robot_id"] = f.cred.RobotID
		} else {
			id["robot_id_claimed"] = f.cred.RobotID
		}
	}
	if f.cred.BotKind == "agent_task" {
		id["credential_kind"] = "agent_task"
	} else if kind := credential.TokenKind(f.cred.Token); kind != "" {
		id["bot_kind"] = kind
	}
	if f.cred.Source != "" {
		id["source"] = f.cred.Source
	}
	return id
}

func (f *Factory) emit(raw []byte, meta output.EnvelopeMeta) error {
	if meta.Identity == nil {
		meta.Identity = f.identityValue()
	}
	// Build the success envelope into an in-memory buffer first so --jq can
	// operate on the canonical envelope shape (not the backend shape).
	var envBuf bytes.Buffer
	if err := output.WriteSuccess(&envBuf, raw, meta); err != nil {
		return err
	}
	// Re-parse into any so Format/ApplyJQ can work with it. UseNumber keeps every
	// integer at its exact decimal text: a plain unmarshal would turn a uint64 id
	// above 2^53 into a rounded float64, silently corrupting it on the way to
	// stdout even when the backend and the transport got it right. gojq handles
	// json.Number for arithmetic, comparison and tostring, and the table/csv
	// renderer prints it verbatim.
	var envelope any
	dec := json.NewDecoder(bytes.NewReader(envBuf.Bytes()))
	dec.UseNumber()
	if err := dec.Decode(&envelope); err != nil {
		return fmt.Errorf("re-parse envelope: %w", err)
	}

	if f.Globals != nil && f.Globals.JQ != "" {
		var results []any
		var err error
		if f.jqProgram != nil && f.jqExpression == f.Globals.JQ {
			results, err = f.jqProgram.Apply(envelope)
		} else {
			results, err = output.ApplyJQ(envelope, f.Globals.JQ)
		}
		if err != nil {
			return err
		}
		// When jq returns a single value, emit it directly; else emit the slice.
		if len(results) == 1 {
			envelope = results[0]
		} else {
			envelope = results
		}
	}
	return output.Format(f.IOStreams.Out, f.Format(), envelope)
}

// EmitError renders an error envelope to stderr. Non-ExitError values are
// classified via WrapCLIError before rendering so the envelope always carries
// a proper taxonomy. Sets ErrorEmitted so the top-level main func can avoid
// double-emitting. Always returns nil so cobra doesn't print its own error
// on top of ours; the caller sets the process exit code separately.
func (f *Factory) EmitError(err error) error {
	f.ErrorEmitted = true
	return output.WriteError(f.IOStreams.ErrOut, WrapCLIError(err))
}

// --- helpers ---

// WrapCLIError classifies a plain error into an *output.ExitError using narrow
// heuristics for the common agent-facing failures (missing token, unknown
// flag, missing arg). Already-wrapped *ExitError values pass through
// unchanged. Everything else falls through to a generic config error so exit
// codes and envelopes stay predictable.
//
// Shared by the root command (for cobra-framework errors) and the Factory
// (for EmitError callers) so both paths produce identical taxonomy.
//
// # Which messages may be echoed, and why
//
// This is the last funnel before stderr, and the stderr envelope is unconditional —
// no --verbose gates it. Five separate rounds of review found a caller-supplied secret
// arriving here through some formatting point, so the rule is written down rather than
// re-derived each time: **a message reaches the envelope only if its text cannot
// contain a value the caller typed.**
//
// The messages that arrive here, by origin:
//
//	origin                     format                                     embeds argv?
//	---------------------------+-------------------------------------------+------------
//	pflag failf (bad syntax)   bad flag syntax: %s                         YES (the whole token)
//	pflag UnknownFlagError     unknown flag: --%s                          YES (the name IS argv)
//	pflag UnknownFlagError     unknown shorthand flag: %q in -%s           YES (the whole run)
//	pflag ValueRequiredError   flag needs an argument: [%q in -]%s         YES (same run)
//	pflag InvalidArgumentError invalid argument %q for %q flag: %v         YES (the value)
//	cobra unknown command      unknown command %q for %q                   YES (the token)
//	this project's             unknown subcommand for %q; available: %s     no (our own words:
//	rejectUnknownSubcommand                                                 the command path and
//	                                                                        our subcommand names)
//	cobra arg count            accepts %d arg(s), received %d              no (counts)
//	cobra minimum args         requires at least %d arg(s), only received  no (counts)
//	cobra required flags       required flag(s) %q not set                 no (flag names)
//	this project's config/     "token is required", "…OCTO_TOKEN…"         no (our own text)
//	credential packages
//
// Note the two "unknown …" rows are different strings from different producers and must
// not be collapsed: cobra quotes the token it did not recognise, while this project's own
// rejectUnknownSubcommand was rewritten in an earlier round precisely so that it names the
// command path and lists the real subcommands instead of echoing the argument. Blanking
// that one would throw away the fix rather than extend it.
//
// pflag has six failf call sites, and the list above matched five of them: `bad flag
// syntax: %s`, whose argument is the entire argv token, was in no branch and printed in
// full. So the rule is inverted rather than extended by one: **within the flag-parse
// family, echoing requires an allowlist entry**, and everything else is reported by
// category. The allowlist is checked first because "required flag(s) …" mentions flags
// too. A seventh failf in a future pflag release is covered without being enumerated,
// which is the whole point — enumerating the unsafe shapes is what missed one.
//
// The categories that embed argv are reported by name instead. That is a real loss of
// detail — an operator no longer sees which flag was rejected — and it is accepted
// because the alternative cannot be made safe here: this runs *before* collectSecrets,
// so there is no list of declared secrets to mask against, and a base64url share or
// invite token beginning with "-" is exactly what pflag reports as an unknown flag.
// The hint carries the remedy, including the "-" case, so the caller is not left
// guessing.
//
// The fallback keeps its text. Everything reaching it either comes from this project's
// own code or is a cobra error not matched above; the standing contract for our own
// code is that an error carrying a caller value must be constructed as an *ExitError
// with the value already masked, which is checked at the sites that have a secret list.
// If a future error type formats argv into an unclassified message, that contract is
// where it has to be fixed — not by widening the guesses here.
func WrapCLIError(err error) error {
	if err == nil {
		return nil
	}
	if ee := output.AsExitError(err); ee != nil {
		return ee
	}
	msg := err.Error()
	lower := strings.ToLower(msg)
	switch {
	case strings.Contains(lower, "octo_task_token"):
		return output.ErrAuth(msg, "the daemon must provide OCTO_TASK_TOKEN for this task invocation")
	case strings.Contains(lower, "octo_token"),
		strings.Contains(lower, "octo_bot_token"),
		strings.Contains(lower, "bot token"),
		strings.Contains(lower, "token is required"):
		return output.ErrAuth(msg, "set OCTO_TOKEN (or OCTO_BOT_TOKEN) to an app_*, bf_*, uk_*, or octo_loop_* token")
	// --- allowlist first: shapes proven to carry no caller value keep their text ---
	//
	// Order matters. These are checked before the family catch-all below, because
	// "required flag(s) …" also mentions flags and would otherwise be blinded along
	// with everything else.
	case strings.Contains(lower, "unknown subcommand"),
		strings.Contains(lower, "required flag"),
		strings.Contains(lower, "accepts "),
		strings.Contains(lower, "requires at "),
		strings.Contains(lower, "arg(s)"):
		return output.ErrValidation(msg, "run `octo-cli <command> --help` to see valid flags and args")

	// --- then the categories reported by name, for a useful remedy ---
	case strings.Contains(lower, "unknown flag"),
		strings.Contains(lower, "unknown shorthand"):
		return output.ErrValidation("a flag in the command line was not recognised",
			"run `octo-cli <command> --help` for the valid flags. If this is an id that starts "+
				"with \"-\" (base64url ids do), pass it as its named flag or after a \"--\" separator")
	case strings.Contains(lower, "flag needs an argument"):
		return output.ErrValidation("a flag was given without its value",
			"run `octo-cli <command> --help` for the valid flags and their arguments")
	case strings.Contains(lower, "invalid argument"):
		return output.ErrValidation("a flag value was rejected by its type",
			"run `octo-cli <command> --help` to see the expected type for each flag")
	case strings.Contains(lower, "bad flag syntax"):
		return output.ErrValidation("a flag in the command line is malformed",
			"a flag is --name or --name=value (or -n); check for a stray dash or a missing name")
	case strings.Contains(lower, "unknown command"):
		return output.ErrValidation("that is not a known command",
			"run `octo-cli --help`, or `octo-cli <domain> --help`, for the available commands")

	// --- and the family catch-all: anything else about flags is not echoed ---
	//
	// This is what makes the rule default-deny rather than a list of known-bad shapes.
	// The previous version enumerated the formats that embed argv and blinded those,
	// which matched five of pflag's six failf sites and missed "bad flag syntax: %s" —
	// the one whose argument is the entire argv token. A sixth strings.Contains would
	// have repeated the same mistake at a different index; this covers the seventh
	// failf a future pflag release adds without anyone having to notice it.
	case strings.Contains(lower, "flag"), strings.Contains(lower, "shorthand"):
		return output.ErrValidation("the command line could not be parsed",
			"run `octo-cli <command> --help` for the valid flags and args")
	}
	return output.ErrWithHint("config", "CLI_ERROR", msg, "")
}

func normalizeRaw(raw []byte) []byte {
	if len(raw) == 0 {
		return nil
	}
	return raw
}

// --- IOStreams writer shim for outbound commands ---

// Out returns the factory's stdout writer. Small convenience used by write paths.
func (f *Factory) Out() io.Writer { return f.IOStreams.Out }

// ErrOut returns the factory's stderr writer.
func (f *Factory) ErrOut() io.Writer { return f.IOStreams.ErrOut }
